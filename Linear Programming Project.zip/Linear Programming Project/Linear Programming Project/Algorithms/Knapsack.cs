﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Linear_Programming_Project.Algorithms
{
	/// <summary>
	/// The KnapsackBranchAndBoundSolver class is designed to solve the knapsack problem using the branch-and-bound algorithm. It begins by initializing with a model that 
	/// defines the problem and calculates efficiency ratios to prioritize items. The algorithm systematically explores different combinations of items by including or excluding them, 
	/// evaluating each branch for feasibility based on remaining capacity and item values. The class provides detailed output throughout the process, including item values, weights, 
	/// and ratios, as well as cumulative weights and decisions at each stage of the search. Ultimately, it identifies and presents the optimal solution, whether the goal is to maximize 
	/// or minimize the value, offering a thorough analysis of potential solutions.
	/// </summary>

	internal class KnapsackBranchAndBoundSolver
	{
		private LinearProgramingModel _optimizationModel; // Model representing the linear programming problem
		private static List<List<object>> _solutions = new List<List<object>>(); // List to store valid solutions
		private static string _outputDetails = ""; // String to store output details

		internal KnapsackBranchAndBoundSolver(LinearProgramingModel model)
		{
			_optimizationModel = model; // Initialize with the provided model
		}

		public KnapsackBranchAndBoundSolver Execute()
		{
			RunKnapsackAlgorithm(_optimizationModel); // Run the knapsack algorithm
			return this;
		}

		public static string RunKnapsackAlgorithm(LinearProgramingModel model)
		{
			// Append initial model information to the output string
			_outputDetails += model.ToString();

			// Compute efficiency ratios and determine item ordering based on these ratios
			List<double> efficiencyRatios = new List<double>();
			List<int> itemOrdering = new List<int>();

			for (int i = 0; i < model.ObjectiveCoefficients.Length; i++)
			{
				// Calculate efficiency ratios
				efficiencyRatios.Add(Math.Round(model.ObjectiveCoefficients[i] / model.Constraints[0, i], 3));
			}

			// Create a list of indexed ratios for sorting
			var indexedRatios = efficiencyRatios.Select((value, index) => new { Value = value, Index = index }).ToList();
			var sortedRatios = indexedRatios.OrderByDescending(x => x.Value).ToList();

			// Reverse order if minimization problem
			if (!model.IsMaximization)
			{
				sortedRatios.Reverse();
			}

			// Create item ordering based on sorted ratios
			for (int i = 0; i < sortedRatios.Count; i++)
			{
				itemOrdering.Add(sortedRatios[i].Index);
			}

			// Extract values and weights from the model
			List<double> values = model.ObjectiveCoefficients.ToList();
			double[] weights = model.Constraints.Cast<double>().ToArray(); // Assuming row-major order

			// Display the efficiency ratios and item ordering
			DisplayRatioAndRanking(efficiencyRatios, itemOrdering, weights, values);

			// Start the knapsack algorithm with initial parameters
			double capacity = model.RHS[0];
			ExecuteAlgorithm("", itemOrdering, new List<List<int>>(), capacity, values, weights);

			// Show the optimal solution found
			ShowOptimalSolution(model);

			// Return the accumulated output details
			return _outputDetails;
		}

		public static void DisplayRatioAndRanking(List<double> ratios, List<int> rankings, double[] objectiveCoefficients, List<double> constraintCoefficients)
		{
			// Prepare data for display
			double[] itemWeights = constraintCoefficients.ToArray();
			double[] itemValues = objectiveCoefficients;
			string[] headers = { "Item", "Ratio", "Ranking" };

			// Create labels for items
			string[] itemLabels = Enumerable.Range(1, itemWeights.Length).Select(i => "X" + i).ToArray();
			string[] orderedLabels = rankings.Select(index => itemLabels[index]).ToArray();

			// Calculate the rankings based on the sorted order of ratios
			var indexedRatios = ratios.Select((value, index) => new { Value = value, Index = index }).ToList();
			var sortedRatios = indexedRatios.OrderByDescending(x => x.Value).ToList();
			int[] ranks = new int[ratios.Count];

			for (int i = 0; i < sortedRatios.Count; i++)
			{
				ranks[sortedRatios[i].Index] = i + 1;  // Assign rank 1 to the highest ratio
			}

			// Calculate column widths for formatting
			int[] columnWidths = new int[]
			{
		Math.Max(headers[0].Length, itemLabels.Max(l => l.Length)),
		Math.Max(headers[1].Length, ratios.Max(r => r.ToString("F3").Length)),
		Math.Max(headers[2].Length, ranks.Max(r => r.ToString().Length)),
			};

			// Display header row
			string headerRow = $"|{headers[0].PadRight(columnWidths[0] + 1)}|{headers[1].PadRight(columnWidths[1] + 1)}|{headers[2].PadRight(columnWidths[2] + 1)}|\n";
			string border = $"|{new string('-', columnWidths[0] + 1)}|{new string('-', columnWidths[1] + 1)}|{new string('-', columnWidths[2] + 1)}|\n";
			Console.Write(border);
			Console.Write(headerRow);
			Console.Write(border);

			// Display rows for each item
			string dataRows = "";
			for (int i = 0; i < itemWeights.Length; i++)
			{
				string dataRow = $"|{itemLabels[i].PadRight(columnWidths[0] + 1)}|{ratios[i].ToString("F3").PadRight(columnWidths[1] + 1)}|{ranks[i].ToString().PadRight(columnWidths[2] + 1)}|\n";
				Console.Write(dataRow);
				dataRows += dataRow;
			}
			Console.Write(border);
			_outputDetails += border + headerRow + border + dataRows + border;
		}

		private static void ExecuteAlgorithm(
    string branchID,
    List<int> availableItems,
    List<List<int>> selectedItemValues,
    double weightCapacity,
    List<double> itemValues,
    double[] itemWeights)
{
    // Initialize lists and variables for the current branch
    var decisionList = new List<double>();
    var cumulativeWeights = new List<double>();
    var variableLabels = new List<string>();
    double remainingCapacity = weightCapacity;
    int feasibilityStatus = 0;

    if (string.IsNullOrEmpty(branchID))
    {
        branchID = "1"; // Initial branch ID
    }

    double totalValue = 0;
    foreach (var item in selectedItemValues)
    {
        // Build branch ID and calculate total value and remaining capacity
        if (item.Equals(selectedItemValues.First()))
        {
            branchID += "." +(item[1] + 1).ToString();
        }
        else
        {
            branchID += "." + (item[1]).ToString(); // Update here to avoid doubling
        }
        variableLabels.Add("X" + (item[0] + 1).ToString() + "*");
        totalValue += itemValues[item[0]] * item[1];
        remainingCapacity -= itemWeights[item[0]] * item[1];
        cumulativeWeights.Add(remainingCapacity);
        decisionList.Add(item[1]);
    }

    // Determine the next items to process
    List<int> nextItems = selectedItemValues.Count == 0
        ? availableItems
        : availableItems.Where(i => !selectedItemValues.Select(s => s[0]).Contains(i)).ToList();

    // Check if the current solution is feasible
    if (remainingCapacity < 0)
    {
        feasibilityStatus = 2; // Infeasible

    }

    if (nextItems.Count == 0)
    {
        // If no more items, finalize the current solution
        string currentBranchInfo = selectedItemValues.Count == 0 ? "" : "X" + (selectedItemValues.Last()[0] + 1).ToString() + "=" + selectedItemValues.Last()[1].ToString();

        if (remainingCapacity < 0)
        {
            feasibilityStatus = 2; // Infeasible
        }
        else
        {
            feasibilityStatus = 1; // Valid candidate
            _solutions.Add(new List<object> { selectedItemValues, totalValue });
        }
        ShowCalculationDetails(branchID, currentBranchInfo, variableLabels, cumulativeWeights, decisionList, feasibilityStatus, totalValue);
        return;
    }

    // Branching: consider including or excluding the next items
    var branchZero = new List<List<int>>();
    var branchOne = new List<List<int>>();

    foreach (var item in nextItems)
    {
        variableLabels.Add("X" + (item + 1).ToString());
        double tempCapacity = remainingCapacity;
        remainingCapacity -= itemWeights[item];
        totalValue += itemValues[item];
        cumulativeWeights.Add(remainingCapacity);

        if (remainingCapacity < 0)
        {
            if (decisionList.Last() == 1 || item == nextItems.First())
            {
                decisionList.Add(tempCapacity / itemWeights[item]);
                if (feasibilityStatus != 2)
                {
                    branchZero = new List<List<int>>(selectedItemValues) { new List<int> { item, 0 } };
                    branchOne = new List<List<int>>(selectedItemValues) { new List<int> { item, 1 } };
                }
            }
            else
            {
                decisionList.Add(0);
            }
        }
        else
        {
            decisionList.Add(1);
        }
    }

    if (remainingCapacity >= 0)
    {
        feasibilityStatus = 1;
        branchOne.Clear();
        branchZero.Clear();
    }

    string branchDescription = selectedItemValues.Count == 0 ? "" : "X" + (selectedItemValues.Last()[0] + 1).ToString() + "=" + selectedItemValues.Last()[1].ToString();

    ShowCalculationDetails(branchID, branchDescription, variableLabels, cumulativeWeights, decisionList, feasibilityStatus, totalValue);

    // Recursively explore branches
    if (feasibilityStatus == 1)
    {
        foreach (var item in nextItems)
        {
            selectedItemValues.Add(new List<int> { item, 1 });
        }
        _solutions.Add(new List<object> { selectedItemValues, totalValue });
    }

    if (branchZero.Count > 0)
    {
        ExecuteAlgorithm(branchID + ".1", availableItems, branchZero, weightCapacity, itemValues, itemWeights);
        ExecuteAlgorithm(branchID + ".2", availableItems, branchOne, weightCapacity, itemValues, itemWeights);
    }
}


		public static int solutionCounter = 0;
		private static void ShowCalculationDetails(
			string branchID,
			string branchInfo,
			List<string> variables,
			List<double> cumulativeWeights,
			List<double> decisions,
			int feasibilityStatus,
			double totalValue = 0)
		{
			// Display branch information
			string branchDetail = $"Branch {branchID}: {branchInfo}\n";
			Console.Write(branchDetail);
			_outputDetails += "\n" + branchDetail;

			// Calculate column widths for formatting
			int varWidth = Math.Max("Variables".Length, variables.Max(v => v.Length));
			int cumSumWidth = Math.Max("Cumulative".Length, cumulativeWeights.Max(c => c.ToString().Length));
			int decisionWidth = Math.Max("Decision".Length, decisions.Max(d => d.ToString().Length));

			// Display header for calculations
			string header = $"|{"Variables".PadRight(varWidth)}|{"Cumulative".PadRight(cumSumWidth)}|{"Decision".PadRight(decisionWidth)}|\n";
			string border = $"|{new string('-', varWidth)}|{new string('-', cumSumWidth)}|{new string('-', decisionWidth)}|\n";
			Console.Write(border);
			Console.Write(header);
			Console.Write(border);
			_outputDetails += border + header + border;

			// Display rows for the current branch
			string rows = "";
			for (int i = 0; i < variables.Count; i++)
			{
				string row = $"|{variables[i].PadRight(varWidth)}|{cumulativeWeights[i].ToString().PadRight(cumSumWidth)}|{Math.Round(decisions[i], 3).ToString().PadRight(decisionWidth)}|\n";
				Console.Write(row);
				rows += row;
			}
			_outputDetails += rows + border;
			Console.Write(border);

			// Display feasibility status
			if (feasibilityStatus == 1)
			{
				solutionCounter++;
				string candidateSolution = $"Candidate {solutionCounter}: {totalValue}\n";
				Console.Write(candidateSolution);
				_outputDetails += candidateSolution;
			}
			else if (feasibilityStatus == 2)
			{
				Console.WriteLine("Infeasible");
				_outputDetails += "Infeasible\n";
			}
			Console.WriteLine();
		}


		private static void ShowOptimalSolution(LinearProgramingModel model)
		{
			string[] headers = { "Variable", "Value" };
			List<string[]> rows = new List<string[]>();

			var optimalSolution = _solutions.OrderByDescending(s => (double)s[1]).FirstOrDefault();

			if (optimalSolution != null)
			{
				var selectedItems = (List<List<int>>)optimalSolution[0];
				double optimalValue = (double)optimalSolution[1];

				foreach (var item in selectedItems)
				{
					rows.Add(new string[] { $"X{item[0] + 1}", item[1].ToString() });
				}

				string table = FormatWithBorders(headers, rows);
				string optimalValueDisplay = model.IsMaximization ? "Max Optimal Value" : "Min Optimal Value";

				Console.WriteLine("\nOptimal Knapsack Solution:");
				Console.WriteLine(table);
				Console.WriteLine($"{optimalValueDisplay}: {optimalValue}\n");
				_outputDetails += "\nOptimal Knapsack Solution:\n" + table + $"\n{optimalValueDisplay}: {optimalValue}\n";
			}
			else
			{
				Console.WriteLine("No feasible solution found.");
				_outputDetails += "No feasible solution found.\n";
			}
		}

		private static string FormatWithBorders(string[] headers, List<string[]> rows)
		{
			int[] columnWidths = headers.Select((header, index) => Math.Max(header.Length, rows.Max(row => row[index].Length))).ToArray();

			string border = "|" + string.Join("|", columnWidths.Select(w => new string('-', w + 2))) + "|";

			string headerRow = "|" + string.Join("|", headers.Select((header, index) => $" {header.PadRight(columnWidths[index])} ")) + "|";

			List<string> formattedRows = rows.Select(row => "|" + string.Join("|", row.Select((cell, index) => $" {cell.PadRight(columnWidths[index])} ")) + "|").ToList();

			return border + "\n" + headerRow + "\n" + border + "\n" + string.Join("\n" + border + "\n", formattedRows) + "\n" + border;
		}
	}
}