﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;

/// <summary>
/// The DualSimplex class implements the Dual Simplex algorithm to solve linear programming problems, specifically designed for cases where dual feasibility is 
/// not guaranteed from the start. The Solve method first converts the linear programming model into its canonical form by adding slack or excess variables.
/// It then performs two phases: the first phase addresses dual feasibility by iteratively selecting pivot rows and columns to handle negative RHS values, while the 
/// second phase optimizes the objective function by again selecting appropriate pivot elements based on the objective function's coefficients. 
/// The results, including the initial and final tables, the history of table states, and the solution status, are encapsulated in a DualSimplexResult object.
/// </summary>

namespace Linear_Programming_Project.Algorithms
{
	// Class to store the results of the Dual Simplex algorithm.
	public class DualSimplexResult
	{
		// Initial simplex table before solving.
		public double[,] InitialTable { get; set; }

		// Final simplex table after solving.
		public double[,] FinalTable { get; set; }

		// List of all simplex table states during the solving process.
		public List<double[,]> TableauHistory { get; set; }

		// Status of the solution (Optimal, Infeasible, or Unbounded).
		public string SolutionStatus { get; set; }
	}

	// Class implementing the Dual Simplex algorithm.
	internal class DualSimplex
	{
		// Main method to solve the linear programming model using Dual Simplex algorithm.
		public DualSimplexResult Solve(LinearProgramingModel model)
		{
			// Convert the model into its canonical form with added slack/excess variables.
			double[,] table = ConvertToCanonicalForm(model);

			// Initialize history with the canonical form.
			List<double[,]> tableauHistory = new List<double[,]>();
			tableauHistory.Add((double[,])table.Clone());

			// Phase 1: Handle dual feasibility by ensuring no negative RHS values.
			while (HasNegativeRHS(table))
			{
				int pivotRow = SelectPivotRow(table);
				int pivotColumn = SelectPivotColumn(table, pivotRow);

				// If no valid pivot column is found, return infeasible or unbounded status.
				if (pivotColumn == -1)
				{
					return new DualSimplexResult
					{
						InitialTable = tableauHistory[0],
						FinalTable = table,
						TableauHistory = tableauHistory,
						SolutionStatus = "Infeasible or Unbounded"
					};
				}

				// Perform pivot operation to update the table.
				PerformPivoting(ref table, pivotRow, pivotColumn);
				tableauHistory.Add((double[,])table.Clone());
			}

			// Phase 2: Optimize the objective function.
			while (HasNegativeObjective(table, model.Objective == "max"))
			{
				int pivotColumn = SelectPivotColumnObjective(table, model.Objective == "max");
				int pivotRow = SelectPivotRowForObjective(table, pivotColumn);

				// If no valid pivot row is found, return infeasible or unbounded status.
				if (pivotRow == -1)
				{
					return new DualSimplexResult
					{
						InitialTable = tableauHistory[0],
						FinalTable = table,
						TableauHistory = tableauHistory,
						SolutionStatus = "Infeasible or Unbounded"
					};
				}

				// Perform pivot operation to update the table.
				PerformPivoting(ref table, pivotRow, pivotColumn);
				tableauHistory.Add((double[,])table.Clone());
			}

			// Return the result object with the final table and solution status.
			return new DualSimplexResult
			{
				InitialTable = tableauHistory[0],
				FinalTable = table,
				TableauHistory = tableauHistory,
				SolutionStatus = "Optimal"
			};
		}

		// Checks if there are negative RHS values in the table.
		private bool HasNegativeRHS(double[,] table)
		{
			int rows = table.GetLength(0);
			for (int i = 1; i < rows; i++)
			{
				if (table[i, table.GetLength(1) - 1] < 0)
				{
					return true;
				}
			}
			return false;
		}

		// Selects the pivot row based on the largest negative RHS value.
		private int SelectPivotRow(double[,] table)
		{
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double largestNegative = 0;

			for (int i = 1; i < rows; i++)
			{
				if (table[i, table.GetLength(1) - 1] < largestNegative)
				{
					largestNegative = table[i, table.GetLength(1) - 1];
					pivotRow = i;
				}
			}
			return pivotRow;
		}

		// Selects the pivot column based on the minimum ratio test.
		private int SelectPivotColumn(double[,] table, int pivotRow)
		{
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double minRatio = double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				if (table[pivotRow, j] < 0)
				{
					double ratio = Math.Abs(table[0, j] / table[pivotRow, j]);
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotColumn = j;
					}
				}
			}
			return pivotColumn;
		}

		// Performs the pivot operation to update the simplex table.
		private void PerformPivoting(ref double[,] table, int pivotRow, int pivotColumn)
		{
			int rows = table.GetLength(0);
			int columns = table.GetLength(1);

			// Normalize the pivot row.
			double pivotElement = table[pivotRow, pivotColumn];
			for (int j = 0; j < columns; j++)
			{
				table[pivotRow, j] /= pivotElement;
			}

			// Update other rows based on the pivot row.
			for (int i = 0; i < rows; i++)
			{
				if (i != pivotRow)
				{
					double rowFactor = table[i, pivotColumn];
					for (int j = 0; j < columns; j++)
					{
						table[i, j] -= rowFactor * table[pivotRow, j];
					}
				}
			}
		}

		// Checks if there are negative coefficients in the objective function row.
		private bool HasNegativeObjective(double[,] table, bool isMax)
		{
			int columns = table.GetLength(1) - 1;
			for (int j = 0; j < columns; j++)
			{
				if (isMax && table[0, j] < 0) return true;
				if (!isMax && table[0, j] > 0) return true;
			}
			return false;
		}

		// Selects the pivot column based on the objective function.
		private int SelectPivotColumnObjective(double[,] table, bool isMax)
		{
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double largestValue = isMax ? 0 : double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				if (isMax && table[0, j] < largestValue)
				{
					largestValue = table[0, j];
					pivotColumn = j;
				}
				else if (!isMax && table[0, j] > largestValue)
				{
					largestValue = table[0, j];
					pivotColumn = j;
				}
			}
			return pivotColumn;
		}

		// Selects the pivot row based on the minimum ratio test for the objective function.
		private int SelectPivotRowForObjective(double[,] table, int pivotColumn)
		{
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double minRatio = double.MaxValue;

			for (int i = 1; i < rows; i++)
			{
				double rhsValue = table[i, table.GetLength(1) - 1];
				double columnValue = table[i, pivotColumn];
				if (columnValue > 0)
				{
					double ratio = rhsValue / columnValue;
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotRow = i;
					}
				}
			}
			return pivotRow;
		}

		// Converts the model into canonical form for the Dual Simplex method.
		public double[,] ConvertToCanonicalForm(LinearProgramingModel model)
		{
			int numVariables = model.ObjectiveCoefficients.Length;
			int numConstraints = model.Constraints.GetLength(0);
			int totalVariables = numVariables + numConstraints;

			// Create a table for the canonical form
			double[,] canonicalForm = new double[numConstraints + 1, totalVariables + 1];

			// Fill objective function row (first row)
			for (int j = 0; j < numVariables; j++)
			{
				// Note: Negating for maximization problems; for minimization, this would be the same
				canonicalForm[0, j] = -model.ObjectiveCoefficients[j];
			}

			// Fill constraints
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < numVariables; j++)
				{
					// Ensure model.Constraints has correct dimensions
					if (i < model.Constraints.GetLength(0) && j < model.Constraints.GetLength(1))
					{
						canonicalForm[i + 1, j] = model.Constraints[i, j];
					}
					else
					{
						// Handle the case where the dimensions do not match
						throw new IndexOutOfRangeException("The constraints matrix does not match the expected dimensions.");
					}
				}

				if (i < model.Signs.Length) // Ensure we do not go out of bounds
				{
					if (model.Signs[i] == ">=")
					{
						canonicalForm[i + 1, numVariables + i] = -1; // Excess variable
						canonicalForm[i + 1, totalVariables] = -model.RHS[i];
					}
					else if (model.Signs[i] == "<=")
					{
						canonicalForm[i + 1, numVariables + i] = 1; // Slack variable
						canonicalForm[i + 1, totalVariables] = model.RHS[i];
					}
				}
			}
			return canonicalForm;
		}
	}
}