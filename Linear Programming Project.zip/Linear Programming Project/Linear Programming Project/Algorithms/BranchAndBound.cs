﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;

namespace Linear_Programming_Project.Algorithms
{
	public class BranchAndBoundResult
	{
		public double[,] InitialTable { get; set; }
		public double[,] FinalTable { get; set; }
		public List<double[,]> TableauHistory { get; set; }
		public string SolutionStatus { get; set; }
		public double BestObjectiveValue { get; set; }
		public Dictionary<string, double> BestSolution { get; set; }
	}

	internal class BranchAndBound
	{
		private double bestObjectiveValue = double.NegativeInfinity;
		private Dictionary<string, double> bestSolution = new Dictionary<string, double>();
		private double[,] bestSolutionTable;
		private List<double[,]> tableauHistory = new List<double[,]>();

		public BranchAndBoundResult Solve(LinearProgramingModel model)
		{
			// Initialize the problem
			LinearProgramingModel rootNode = (LinearProgramingModel)model.Clone();
			tableauHistory.Clear();

			// Record initial table
			tableauHistory.Add(rootNode.Constraints);

			SolveNode(rootNode);

			return new BranchAndBoundResult
			{
				InitialTable = rootNode.Constraints,
				FinalTable = bestSolutionTable,
				TableauHistory = tableauHistory,
				SolutionStatus = bestObjectiveValue == double.NegativeInfinity ? "Infeasible" : "Optimal",
				BestObjectiveValue = bestObjectiveValue,
				BestSolution = bestSolution
			};
		}

		private void SolveNode(LinearProgramingModel node)
		{
			// Solve LP relaxation using Primal Simplex
			var primalSimplex = new PrimalSimplex();
			var primalSimplexResult = primalSimplex.Solve(node);

			// Record the table after each iteration
			tableauHistory.Add(primalSimplexResult.FinalTable);

			// Check for feasibility
			if (primalSimplexResult.SolutionStatus == "Infeasible")
				return;

			// Check for integrality
			if (IsIntegerSolution(primalSimplexResult.FinalTable))
			{
				double objectiveValue = CalculateObjectiveValue(primalSimplexResult.FinalTable, node);
				if (objectiveValue > bestObjectiveValue)
				{
					bestObjectiveValue = objectiveValue;
					bestSolution = ExtractSolution(primalSimplexResult.FinalTable);
					bestSolutionTable = primalSimplexResult.FinalTable;
				}
			}
			else
			{
				// Branch on fractional variable
				int variableIndex = GetFractionalVariableIndex(primalSimplexResult.FinalTable);
				if (variableIndex >= 0)
				{
					// Create new branches
					var lowerBoundModel = (LinearProgramingModel)node.Clone();
					AddConstraint(lowerBoundModel, variableIndex, "lower");

					var upperBoundModel = (LinearProgramingModel)node.Clone();
					AddConstraint(upperBoundModel, variableIndex, "upper");

					SolveNode(lowerBoundModel);
					SolveNode(upperBoundModel);
				}
			}
		}

		private bool IsIntegerSolution(double[,] finalTable)
		{
			// Check if all the decision variables (excluding slack variables) are integers
			int numVariables = finalTable.GetLength(1) - 1; // Excluding RHS column
			for (int i = 0; i < numVariables; i++)
			{
				double value = finalTable[i, finalTable.GetLength(1) - 1]; // Assuming last column has the solution values
				if (Math.Abs(value - Math.Round(value)) > 1e-5) // Tolerance for floating-point comparison
				{
					return false;
				}
			}
			return true;
		}

		private double CalculateObjectiveValue(double[,] finalTable, LinearProgramingModel model)
		{
			int numVariables = model.ObjectiveCoefficients.Length;
			double objectiveValue = 0.0;

			for (int i = 0; i < numVariables; i++)
			{
				objectiveValue += finalTable[i, finalTable.GetLength(1) - 1] * model.ObjectiveCoefficients[i];
			}

			return objectiveValue;
		}

		private Dictionary<string, double> ExtractSolution(double[,] finalTable)
		{
			var solution = new Dictionary<string, double>();
			int numVariables = finalTable.GetLength(1) - 1; // Excluding RHS column

			for (int i = 0; i < numVariables; i++)
			{
				solution[$"X{i + 1}"] = finalTable[i, finalTable.GetLength(1) - 1];
			}

			return solution;
		}

		private int GetFractionalVariableIndex(double[,] finalTable)
		{
			// Find the first variable with a fractional part in the solution
			int numVariables = finalTable.GetLength(1) - 1; // Excluding RHS column

			for (int i = 0; i < numVariables; i++)
			{
				double value = finalTable[i, finalTable.GetLength(1) - 1]; // Assuming last column has the solution values
				if (Math.Abs(value - Math.Round(value)) > 1e-5) // Tolerance for floating-point comparison
				{
					return i;
				}
			}

			return -1; // No fractional variable found
		}

		private void AddConstraint(LinearProgramingModel model, int variableIndex, string boundType)
		{
			int numConstraints = model.Constraints.GetLength(0);
			int numVariables = model.Constraints.GetLength(1) - 1; // Excluding RHS column

			double[,] newConstraints = new double[numConstraints + 1, numVariables + 1];
			double[] newRHS = new double[numConstraints + 1];

			// Copy existing constraints
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < numVariables; j++)
				{
					newConstraints[i, j] = model.Constraints[i, j];
				}
				newRHS[i] = model.RHS[i];
			}

			// Add new constraint
			double fractionalValue = model.Constraints[variableIndex, numVariables];
			double lowerBound = Math.Floor(fractionalValue);
			double upperBound = Math.Ceiling(fractionalValue);

			if (boundType == "lower")
			{
				// xi >= lowerBound
				for (int j = 0; j < numVariables; j++)
				{
					newConstraints[numConstraints, j] = (j == variableIndex) ? 1 : 0;
				}
				newRHS[numConstraints] = lowerBound;
			}
			else if (boundType == "upper")
			{
				// xi <= upperBound
				for (int j = 0; j < numVariables; j++)
				{
					newConstraints[numConstraints, j] = (j == variableIndex) ? -1 : 0;
				}
				newRHS[numConstraints] = -upperBound;
			}

			model.Constraints = newConstraints;
			model.RHS = newRHS;
		}
	}
}