﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// The provided code implements the Primal Simplex algorithm for solving linear programming problems. The PrimalSimplex class contains methods to solve 
/// the model, initialize tables, and perform simplex operations. It starts by creating an initial table from the given linear programming model, which includes 
/// constraints and objective functions. The algorithm iterates through the simplex method by selecting entering and leaving variables to pivot until an optimal 
/// solution is found or the problem is deemed infeasible or unbounded. The solution's status and historical tableau states are stored in a PrimalSimplexResult 
/// object, which is returned after the algorithm completes. The PrimalSimplex class also includes methods for cloning matrices, checking optimality and feasibility, 
/// and performing pivot operations to update the simplex table.
/// </summary>

namespace Linear_Programming_Project.Algorithms
{
	// Class to store the results of the Primal Simplex algorithm.
	public class PrimalSimplexResult
	{
		// Canonical form of the linear programming model.
		public double[,] CanonicalForm { get; set; }

		// Initial table created from the canonical form.
		public double[,] InitialTable { get; set; }

		// History of all the tableau states during the algorithm execution.
		public List<double[,]> TableauHistory { get; set; }

		// Final table after the algorithm completes.
		public double[,] FinalTable { get; set; }

		// Status of the solution (Optimal, Infeasible, or Unbounded).
		public string SolutionStatus { get; set; }
	}

	// Class implementing the Primal Simplex algorithm.
	internal class PrimalSimplex
	{
		// Main method to solve the linear programming model using Primal Simplex algorithm.
		public PrimalSimplexResult Solve(LinearProgramingModel model)
		{
			// Create a new result object to store the output.
			var result = new PrimalSimplexResult();

			// Initialize the tables and history.
			Initialize(model, result);

			// Iterate until an optimal solution is found or the problem is identified as infeasible.
			while (!IsOptimal(result.FinalTable) && !IsInfeasible(result.FinalTable))
			{
				// Select the entering variable (column) for the pivot operation.
				int entering = SelectEnteringVariable(result.FinalTable);

				// Select the leaving variable (row) for the pivot operation.
				int leaving = SelectLeavingVariable(result.FinalTable, entering);

				// If no valid leaving variable is found, the problem is unbounded.
				if (leaving == -1)
				{
					result.SolutionStatus = "Unbounded";
					break;
				}

				// Perform the pivot operation to update the table.
				Pivot(result.FinalTable, entering, leaving);

				// Save the current state of the table in history.
				result.TableauHistory.Add(CloneMatrix(result.FinalTable));
			}

			// Set the solution status based on the final table state.
			if (IsOptimal(result.FinalTable))
			{
				result.SolutionStatus = "Optimal";
			}
			else if (IsInfeasible(result.FinalTable))
			{
				result.SolutionStatus = "Infeasible";
			}

			// Return the result object containing the solution and history.
			return result;
		}

		// Initializes the result object with the canonical form and initial table.
		private void Initialize(LinearProgramingModel model, PrimalSimplexResult result)
		{
			result.CanonicalForm = CreateInitialTable(model);
			result.InitialTable = result.CanonicalForm;
			result.FinalTable = (double[,])result.InitialTable.Clone();
			result.TableauHistory = new List<double[,]>();
		}

		// Creates the initial simplex table from the linear programming model.
		public double[,] CreateInitialTable(LinearProgramingModel model)
		{
			int numRows = model.Constraints.GetLength(0); // Number of constraints
			int numCols = model.ObjectiveCoefficients.Length + numRows + 1; // Variables + Slack variables + RHS
			double[,] table = new double[numRows + 1, numCols]; // Added one row for Objective Function

			// Fill the table with the constraints and slack variables
			for (int i = 0; i < numRows; i++)
			{
				for (int j = 0; j < model.ObjectiveCoefficients.Length; j++)
				{
					table[i + 1, j] = model.Constraints[i, j];
				}
				table[i + 1, model.ObjectiveCoefficients.Length + i] = 1; // Slack variable
				table[i + 1, numCols - 1] = model.RHS[i]; // RHS value
			}

			// Objective Function
			table[0, 0] = 1; // z = 0
			for (int j = 0; j < model.ObjectiveCoefficients.Length; j++)
			{
				table[0, j] = -model.ObjectiveCoefficients[j];
			}
			return table;
		}

		// Creates the canonical form of the linear programming model.
		public double[,] CreateCanonicalForm(LinearProgramingModel model)
		{
			int numRows = model.Constraints.GetLength(0); // Number of constraints
			int numCols = model.ObjectiveCoefficients.Length + numRows; // Variables + Slack variables

			double[,] canonicalForm = new double[numRows + 1, numCols + 1]; // Extra row for objective function

			// Objective Function: z = -c1*x1 - c2*x2 - ... - cn*xn
			for (int j = 0; j < model.ObjectiveCoefficients.Length; j++)
			{
				canonicalForm[0, j] = -model.ObjectiveCoefficients[j];
			}

			// Constraints
			for (int i = 0; i < numRows; i++)
			{
				for (int j = 0; j < model.ObjectiveCoefficients.Length; j++)
				{
					canonicalForm[i + 1, j] = model.Constraints[i, j];
				}

				// Add slack or excess variables based on constraint sign
				if (model.Signs[i] == "<=")
				{
					canonicalForm[i + 1, model.ObjectiveCoefficients.Length + i] = 1; // Slack variable
					canonicalForm[i + 1, numCols] = model.RHS[i]; // RHS value
				}
				else if (model.Signs[i] == ">=")
				{
					canonicalForm[i + 1, model.ObjectiveCoefficients.Length + i] = -1; // Excess variable
					canonicalForm[i + 1, numCols] = -model.RHS[i]; // RHS value
				}
			}
			return canonicalForm;
		}

		// Checks if the current table represents an optimal solution.
		private bool IsOptimal(double[,] table)
		{
			int numCols = table.GetLength(1);
			for (int j = 0; j < numCols - 1; j++)
			{
				if (table[0, j] < 0)
				{
					return false;
				}
			}
			return true;
		}

		// Checks if the current table represents an infeasible solution.
		private bool IsInfeasible(double[,] table)
		{
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			for (int i = 1; i < numRows; i++)
			{
				if (table[i, numCols - 1] < 0)
				{
					return true;
				}
			}
			return false;
		}

		// Selects the entering variable (column) for the pivot operation based on the most negative value in the objective row.
		private int SelectEnteringVariable(double[,] table)
		{
			int numCols = table.GetLength(1);
			int entering = 0;
			double minValue = table[0, 0];

			for (int j = 1; j < numCols - 1; j++)
			{
				if (table[0, j] < minValue)
				{
					minValue = table[0, j];
					entering = j;
				}
			}

			return entering;
		}

		// Selects the leaving variable (row) for the pivot operation based on the minimum ratio test.
		private int SelectLeavingVariable(double[,] table, int entering)
		{
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			double minRatio = double.MaxValue;
			int leaving = -1;

			for (int i = 1; i < numRows; i++)
			{
				if (table[i, entering] > 0)
				{
					double ratio = table[i, numCols - 1] / table[i, entering];
					if (ratio < minRatio)
					{
						minRatio = ratio;
						leaving = i;
					}
				}
			}

			return leaving;
		}

		// Performs the pivot operation on the table.
		private void Pivot(double[,] table, int entering, int leaving)
		{
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			double pivotElement = table[leaving, entering];

			// Normalize the pivot row.
			for (int j = 0; j < numCols; j++)
			{
				table[leaving, j] /= pivotElement;
			}

			// Update other rows.
			for (int i = 0; i < numRows; i++)
			{
				if (i != leaving)
				{
					double multiplier = table[i, entering];
					for (int j = 0; j < numCols; j++)
					{
						table[i, j] -= multiplier * table[leaving, j];
					}
				}
			}
		}

		// Creates a deep copy of the matrix.
		private double[,] CloneMatrix(double[,] original)
		{
			int rows = original.GetLength(0);
			int cols = original.GetLength(1);
			var clone = new double[rows, cols];

			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < cols; j++)
				{
					clone[i, j] = original[i, j];
				}
			}
			return clone;
		}
	}
}