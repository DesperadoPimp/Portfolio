﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Linear_Programming_Project.Algorithms
{
	// Class to store results of the Cutting Plane algorithm
	public class CuttingPlaneResult
	{
		public double[,] InitialTable { get; set; } // Initial simplex table
		public double[,] FinalTable { get; set; }   // Final simplex table after cuts
		public List<double[,]> TableauHistory { get; set; } // History of all tables during the process
		public List<double[,]> CutTableaus { get; set; } // Tables after each cut
		public string SolutionStatus { get; set; } // Status of the solution (e.g., Optimal, Infeasible)
		public double[] Solution { get; set; } // Final solution vector
		public List<string> CutConstraints { get; set; } // List of cut constraints added
		public int FractionalVariableIndex { get; set; } // Index of the fractional variable
	}

	// Enum for different algorithm types
	public enum AlgorithmType
	{
		PrimalSimplex,
		DualSimplex
	}

	internal class CuttingPlane
	{
		// Main method to solve the LP problem using Cutting Plane method
		public CuttingPlaneResult Solve(LinearProgramingModel model)
		{
			var result = new CuttingPlaneResult
			{
				TableauHistory = new List<double[,]>(),
				CutConstraints = new List<string>()
			};

			// Initialize Primal Simplex algorithm
			PrimalSimplex primalSimplex = new PrimalSimplex();
			PrimalSimplexResult initialResult = primalSimplex.Solve(model);
			result.InitialTable = initialResult.FinalTable;

			// Add the initial table to history
			result.TableauHistory.Add((double[,])result.InitialTable.Clone());

			// Choose the algorithm based on sign restrictions
			if (model.SignRestrictions.All(sign => sign == "<="))
			{
				result = SolveCuttingPlane(model, result, AlgorithmType.PrimalSimplex);
			}
			else
			{
				result = SolveCuttingPlane(model, result, AlgorithmType.DualSimplex);
			}

			// Add Gomory Cuts if needed
			AddGomoryCuts(model, result);

			return result;
		}

		// Method to solve the Cutting Plane problem using specified algorithm
		private CuttingPlaneResult SolveCuttingPlane(LinearProgramingModel model, CuttingPlaneResult result, AlgorithmType algorithmType)
		{
			if (algorithmType == AlgorithmType.PrimalSimplex)
			{
				PrimalSimplex primalSimplex = new PrimalSimplex();
				PrimalSimplexResult primalResult = primalSimplex.Solve(model);
				result.FinalTable = primalResult.FinalTable;
				result.SolutionStatus = primalResult.SolutionStatus;
			}
			else if (algorithmType == AlgorithmType.DualSimplex)
			{
				DualSimplex dualSimplex = new DualSimplex();
				DualSimplexResult dualResult = dualSimplex.Solve(model);
				result.FinalTable = dualResult.FinalTable;
				result.SolutionStatus = dualResult.SolutionStatus;
			}

			// Add the final table to history
			result.TableauHistory.Add((double[,])result.FinalTable.Clone());
			return result;
		}

		// Method to add Gomory Cuts to the model
		private void AddGomoryCuts(LinearProgramingModel model, CuttingPlaneResult result)
		{
			bool hasFractionalSolution = true;

			while (hasFractionalSolution)
			{
				int fractionalVariableIndex = -1;
				double closestToHalf = double.MaxValue;

				// List to track rows with the same distance to 0.5
				var fractionalRows = new List<int>();

				// Check for fractional basic variables in the optimal solution
				for (int i = 1; i < result.FinalTable.GetLength(0); i++)
				{
					double rhsValue = result.FinalTable[i, result.FinalTable.GetLength(1) - 1];
					double fractionalPart = rhsValue - Math.Floor(rhsValue);

					if (fractionalPart > 0 && fractionalPart < 1)
					{
						double distanceToHalf = Math.Abs(fractionalPart - 0.5);

						if (distanceToHalf < closestToHalf)
						{
							closestToHalf = distanceToHalf;
							fractionalVariableIndex = i;
							fractionalRows.Clear();
							fractionalRows.Add(i);
						}
						else if (distanceToHalf == closestToHalf)
						{
							fractionalRows.Add(i);
						}
					}
				}

				if (fractionalRows.Count > 1)
				{
					// Resolve tie by selecting the row with the leftmost basic variable
					fractionalVariableIndex = fractionalRows
						.OrderBy(row => GetLeftmostBasicVariableColumn(result.FinalTable, row))
						.First();
				}
				else if (fractionalVariableIndex == -1)
				{
					// No fractional parts found, terminate
					hasFractionalSolution = false;
					break;
				}

				// Create a new cut for the selected fractional variable
				CreateGomoryCut(result, fractionalVariableIndex);

				// Display the new initial table with the new constraint added
				Console.WriteLine("\nNew Initial Table with the added constraint:");
				PrintTable(result.FinalTable);
				result.FractionalVariableIndex = fractionalVariableIndex;

				// Solve the new tableau with the added cut using Dual Simplex
				result.FinalTable = SolveDual(result.FinalTable, model);

				// Check if the new solution is integer feasible
				hasFractionalSolution = result.FinalTable.Cast<double>()
					.Where((value, index) => index % result.FinalTable.GetLength(1) == result.FinalTable.GetLength(1) - 1)
					.Any(rhsValue => rhsValue != Math.Floor(rhsValue));
			}
		}

		// Method to solve the dual problem for feasibility and optimization
		public double[,] SolveDual(double[,] table, LinearProgramingModel model)
		{
			// Phase 1: Handle dual feasibility by ensuring no negative RHS values
			while (HasNegativeRHS(table))
			{
				int pivotRow = SelectPivotRow(table);
				int pivotColumn = SelectPivotColumn(table, pivotRow);

				// If no valid pivot column is found, return infeasible or unbounded status
				if (pivotColumn == -1)
				{
					return table;
				}

				// Perform pivot operation to update the table
				PerformPivoting(ref table, pivotRow, pivotColumn);
			}

			// Phase 2: Optimize the objective function
			while (HasNegativeObjective(table, model.Objective == "max"))
			{
				int pivotColumn = SelectPivotColumnObjective(table, model.Objective == "max");
				int pivotRow = SelectPivotRowForObjective(table, pivotColumn);

				// If no valid pivot row is found, return infeasible or unbounded status
				if (pivotRow == -1)
				{
					return table;
				}

				// Perform pivot operation to update the table
				PerformPivoting(ref table, pivotRow, pivotColumn);
			}

			// Return the final table after all operations
			return table;
		}

		// Helper methods for the dual solution process
		private bool HasNegativeRHS(double[,] table)
		{
			int rows = table.GetLength(0);
			for (int i = 1; i < rows; i++)
			{
				if (table[i, table.GetLength(1) - 1] < 0)
				{
					return true;
				}
			}
			return false;
		}

		private int SelectPivotRow(double[,] table)
		{
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double largestNegative = 0;

			for (int i = 1; i < rows; i++)
			{
				if (table[i, table.GetLength(1) - 1] < largestNegative)
				{
					largestNegative = table[i, table.GetLength(1) - 1];
					pivotRow = i;
				}
			}
			return pivotRow;
		}

		private int SelectPivotColumn(double[,] table, int pivotRow)
		{
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double minRatio = double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				if (table[pivotRow, j] < 0)
				{
					double ratio = Math.Abs(table[0, j] / table[pivotRow, j]);
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotColumn = j;
					}
				}
			}
			return pivotColumn;
		}

		private void PerformPivoting(ref double[,] table, int pivotRow, int pivotColumn)
		{
			int rows = table.GetLength(0);
			int columns = table.GetLength(1);

			// Normalize the pivot row
			double pivotElement = table[pivotRow, pivotColumn];
			for (int j = 0; j < columns; j++)
			{
				table[pivotRow, j] /= pivotElement;
			}

			// Eliminate other rows
			for (int i = 0; i < rows; i++)
			{
				if (i != pivotRow)
				{
					double factor = table[i, pivotColumn];
					for (int j = 0; j < columns; j++)
					{
						table[i, j] -= factor * table[pivotRow, j];
					}
				}
			}
		}

		private bool HasNegativeObjective(double[,] table, bool isMaximization)
		{
			int columns = table.GetLength(1);
			for (int j = 0; j < columns - 1; j++)
			{
				if ((isMaximization && table[0, j] < 0) || (!isMaximization && table[0, j] > 0))
				{
					return true;
				}
			}
			return false;
		}

		private int SelectPivotColumnObjective(double[,] table, bool isMaximization)
		{
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double extremeValue = isMaximization ? double.MinValue : double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				if ((isMaximization && table[0, j] > extremeValue) || (!isMaximization && table[0, j] < extremeValue))
				{
					extremeValue = table[0, j];
					pivotColumn = j;
				}
			}
			return pivotColumn;
		}

		private int SelectPivotRowForObjective(double[,] table, int pivotColumn)
		{
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double minRatio = double.MaxValue;

			for (int i = 1; i < rows; i++)
			{
				if (table[i, pivotColumn] > 0)
				{
					double ratio = table[i, table.GetLength(1) - 1] / table[i, pivotColumn];
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotRow = i;
					}
				}
			}
			return pivotRow;
		}

		private int GetLeftmostBasicVariableColumn(double[,] table, int row)
		{
			int numCols = table.GetLength(1);

			// Find the leftmost column with a value of 1 in the given row
			for (int j = 0; j < numCols - 1; j++)
			{
				if (Math.Abs(table[row, j] - 1) < 1e-10)
				{
					return j;
				}
			}
			return -1; // Return -1 if no basic variable is found
		}


		private void CreateGomoryCut(CuttingPlaneResult result, int rowIndex)
		{
			int numRows = result.FinalTable.GetLength(0);
			int numCols = result.FinalTable.GetLength(1);
			double[,] newTable = new double[numRows + 1, numCols + 1];

			// Copy the existing table to the new table
			for (int i = 0; i < numRows; i++)
			{
				for (int j = 0; j < numCols - 1; j++)
				{
					newTable[i, j] = result.FinalTable[i, j];
				}

				// Copy the RHS value to the new position (before the last column)
				newTable[i, numCols] = result.FinalTable[i, numCols - 1];
			}

			// Generate the new cut constraint
			for (int j = 0; j < numCols - 1; j++)
			{
				double value = result.FinalTable[rowIndex, j];
				double fractionalPart = value - Math.Floor(value);
				newTable[numRows, j] = Math.Abs(fractionalPart) < 1e-10 ? 0.00 : -fractionalPart;
			}

			// Set the RHS value of the new constraint
			double rhsValue = result.FinalTable[rowIndex, numCols - 1];
			double fractionalRHS = rhsValue - Math.Floor(rhsValue);
			newTable[numRows, numCols] = Math.Abs(fractionalRHS) < 1e-10 ? 0.00 : -fractionalRHS;

			// Add the new excess variable before the RHS column
			newTable[numRows, numCols - 1] = 1;

			// Replace the old table with the new table with the added cut
			result.FinalTable = newTable;

			// Add to history
			result.TableauHistory.Add((double[,])result.FinalTable.Clone());
		}

		private void PrintTable(double[,] table)
		{
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);

			for (int i = 0; i < numRows; i++)
			{
				for (int j = 0; j < numCols; j++)
				{
					Console.Write($"{table[i, j]:F2}\t");
				}
				Console.WriteLine();
			}
			Console.WriteLine();
		}
	}
}