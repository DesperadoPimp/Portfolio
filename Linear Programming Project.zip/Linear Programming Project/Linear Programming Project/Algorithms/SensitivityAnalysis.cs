﻿using Linear_Programming_Project.BusinessLogic;
using MathNet.Numerics.LinearAlgebra;
using System;
using System.Linq;
using MathNet.Numerics.LinearAlgebra.Double;
using System.Data;
using LpSolveDotNet;
using Accord.IO;
using Accord.Math;
using System.Security.Cryptography;
using Accord.MachineLearning.Performance;

namespace Linear_Programming_Project.Algorithms
{
	internal class SensitivityAnalysis
	{
		private double[,] N;
		private double[,] B;
		private double[] cBv;
		private double[] nCbv;
		private double[,] B_inv;
		private double[] cBvB_inv;
		private double[] rhs;
		private int[,] cbvMatrixIndices;
		private int[,] ncbvMatrixIndices;
		private (int, int, bool)[] variablePositions;
		private int numVariables;
		private int numConstraints;
		int numColumns;

//Sensitivity Analysis methods and their helper methods
		public void NonBasicVariableOBFunChange(AlgorithmResults lastResults)
		{
			if (lastResults == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = lastResults.InitialTable;
			double[,] finalTable = lastResults.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1;
			int numConstraints = initialTable.GetLength(0) - 1;

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			Console.WriteLine("\nNon-basic variables:");
			for (int i = 0; i < nonBasicVariableIndices.Length; i++)
			{
				Console.WriteLine($"\tX{nonBasicVariableIndices[i] + 1}");
			}

			Console.Write("\nEnter the non-basic variable (e.g., X3): ");
			string variableInput = Console.ReadLine();
			int variableIndex = int.Parse(variableInput.Substring(1)) - 1;

			int nCbvIndex = Array.IndexOf(nonBasicVariableIndices, variableIndex);

			if (nCbvIndex == -1)
			{
				Console.WriteLine("Error: Invalid non-basic variable.");
				return;
			}

			Console.Write("\nEnter the new objective function value: ");
			double newValue = double.Parse(Console.ReadLine());

			// Update matrices
			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);
			nCbv[nCbvIndex] = newValue;

			// Display updated matrices
			Console.WriteLine("\nUpdated Matrices:");
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);
			Console.WriteLine("\nNote: As a non-basic objective function value was updated, it only affects the nCbv Matrix and thus only that variable's Objective Function value is changed in the new Optimal Table");

			// Calculate the allowable increase and decrease
			double[] delta = new double[numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				delta[i] = 0;
				for (int j = 0; j < nonBasicVariableIndices.Length; j++)
				{
					delta[i] += N[i, j] * B_inv[i, nCbvIndex];
				}
			}

			double lowerBound = double.NegativeInfinity;
			double upperBound = double.PositiveInfinity;

			for (int i = 0; i < delta.Length; i++)
			{
				if (delta[i] > 0)
				{
					upperBound = Math.Min(upperBound, cBvB_inv[i] / delta[i]);
				}
				else if (delta[i] < 0)
				{
					lowerBound = Math.Max(lowerBound, cBvB_inv[i] / delta[i]);
				}
			}
			Console.WriteLine($"\nAllowable increase: {(upperBound == double.PositiveInfinity ? "∞" : upperBound.ToString())}");
			Console.WriteLine($"\nAllowable decrease: {(lowerBound == double.NegativeInfinity ? "-∞" : lowerBound.ToString())}");
		}

		public void BasicVariableOBFunChange(AlgorithmResults lastResults)
		{
			if (lastResults == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = lastResults.InitialTable;
			double[,] finalTable = lastResults.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1; //exclude RHS
			int numConstraints = initialTable.GetLength(0) - 1; //Exclude Objective Function row

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			Console.WriteLine("\nBasic variables:");
			for (int i = 0; i < basicVariableIndices.Length; i++)
			{
				Console.WriteLine($"\tX{basicVariableIndices[i] + 1}");
			}

			Console.Write("\nEnter the basic variable (e.g., X2): ");
			string variableInput = Console.ReadLine();
			int variableIndex = int.Parse(variableInput.Substring(1)) - 1;

			int basicCbvIndex = Array.IndexOf(basicVariableIndices, variableIndex);

			if (basicCbvIndex == -1)
			{
				Console.WriteLine("Error: Invalid basic variable.");
				return;
			}

			Console.Write("\nEnter the new value: ");
			double newValue = double.Parse(Console.ReadLine());

			// Update matrices
			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);
			cBv[basicCbvIndex] = newValue;
			cBvB_inv = Multiply(cBv, B_inv);

			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table (not implemented)
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);

			Console.WriteLine("\nNote: As a basic objective function value was updated, it only affects the cBv Matrix and thus " +
				"only that variable's Objective Function value is changed in the new Optimal Table");

			// Calculate the allowable increase and decrease
			double[] delta = new double[numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				delta[i] = 0;
				for (int j = 0; j < basicVariableIndices.Length; j++)
				{
					delta[i] += N[i, j] * B_inv[i, basicCbvIndex];
				}
			}

			double lowerBound = double.NegativeInfinity;
			double upperBound = double.PositiveInfinity;

			for (int i = 0; i < delta.Length; i++)
			{
				if (delta[i] > 0)
				{
					upperBound = Math.Min(upperBound, cBvB_inv[i] / delta[i]);
				}
				else if (delta[i] < 0)
				{
					lowerBound = Math.Max(lowerBound, cBvB_inv[i] / delta[i]);
				}
			}

			Console.WriteLine($"\nAllowable increase: {(upperBound == double.PositiveInfinity ? "∞" : upperBound.ToString())}");
			Console.WriteLine($"\nAllowable decrease: {(lowerBound == double.NegativeInfinity ? "-∞" : lowerBound.ToString())}");
		}

		public void RHSVariableChange(AlgorithmResults lastResults)
		{
			if (lastResults == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = lastResults.InitialTable;
			double[,] finalTable = lastResults.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1; // exclude RHS
			int numConstraints = initialTable.GetLength(0) - 1; // exclude Objective Function row

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			CreateMatrices(lastResults.InitialTable, GetBasicVariableIndices(lastResults.FinalTable, lastResults.InitialTable.GetLength(1) - 1, lastResults.InitialTable.GetLength(0) - 1),
				Enumerable.Range(0, lastResults.InitialTable.GetLength(1) - 1).Except(GetBasicVariableIndices(lastResults.FinalTable, lastResults.InitialTable.GetLength(1) - 1, lastResults.InitialTable.GetLength(0) - 1)).ToArray(),
				lastResults.InitialTable.GetLength(0) - 1);

			// Display current RHS values
			Console.WriteLine("\nCurrent RHS values:");
			for (int i = 0; i < rhs.Length; i++)
			{
				Console.WriteLine($"Constraint {i + 1}: {rhs[i]}");
			}

			// Prompt user to select which constraint value to change
			Console.Write("\nEnter the constraint number you want to change (e.g., 1, 2, ...): ");
			if (!int.TryParse(Console.ReadLine(), out int constraintNumber) || constraintNumber < 1 || constraintNumber > rhs.Length)
			{
				Console.WriteLine("Error: Invalid constraint number.");
				return;
			}

			// Get index of the selected constraint
			int constraintIndex = constraintNumber - 1;

			// Prompt user for the new value
			Console.Write("\nEnter the new value for the selected constraint: ");
			if (!double.TryParse(Console.ReadLine(), out double newValue))
			{
				Console.WriteLine("Error: Invalid value.");
				return;
			}

			// Update the RHS matrix
			rhs[constraintIndex] = newValue;

			// Update B matrix with the new RHS values
			var updatedInitialTable = (double[,])initialTable.Clone();
			for (int i = 0; i < numConstraints; i++)
			{
				updatedInitialTable[i + 1, numVariables] = rhs[i];
			}

			// Recalculate matrices using the updated RHS values
			CreateMatrices(updatedInitialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Print updated matrices
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table (not implemented)
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);

			// Calculate allowable increase and decrease
			double[] delta = new double[rhs.Length];
			for (int i = 0; i < rhs.Length; i++)
			{
				delta[i] = 0;
				for (int j = 0; j < N.GetLength(1); j++)
				{
					delta[i] += N[i, j] * B_inv[i, constraintIndex];
				}
			}

			double lowerBound = double.NegativeInfinity;
			double upperBound = double.PositiveInfinity;

			for (int i = 0; i < delta.Length; i++)
			{
				if (delta[i] > 0)
				{
					upperBound = Math.Min(upperBound, cBvB_inv[i] / delta[i]);
				}
				else if (delta[i] < 0)
				{
					lowerBound = Math.Max(lowerBound, cBvB_inv[i] / delta[i]);
				}
			}

			Console.WriteLine($"\nAllowable increase: {(upperBound == double.PositiveInfinity ? "∞" : upperBound.ToString())}");
			Console.WriteLine($"\nAllowable decrease: {(lowerBound == double.NegativeInfinity ? "-∞" : lowerBound.ToString())}");
		}

		public void NonBasicColumnVariableChange(AlgorithmResults results)
		{
			if (results == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = results.InitialTable;
			double[,] finalTable = results.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1;
			int numConstraints = initialTable.GetLength(0) - 1;

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Display the N matrix
			Console.WriteLine("\nN Matrix:");
			PrintMatrixDouble2DArray(N, nonBasicVariableIndices);

			// Prompt the user to select which variable to change
			Console.Write("\nEnter the non-basic variable you want to change (e.g., X3): ");
			string variableInput = Console.ReadLine();
			if (!variableInput.StartsWith("X") || !int.TryParse(variableInput.Substring(1), out int variableNumber))
			{
				Console.WriteLine("Error: Invalid variable format.");
				return;
			}
			int variableIndex = variableNumber - 1;

			int columnIndex = Array.IndexOf(nonBasicVariableIndices, variableIndex);
			if (columnIndex == -1)
			{
				Console.WriteLine("Error: Invalid non-basic variable.");
				return;
			}

			// Prompt the user to select which constraint to change
			Console.Write("\nEnter the constraint number you want to change (e.g., 1, 2, ...): ");
			if (!int.TryParse(Console.ReadLine(), out int constraintNumber) || constraintNumber < 1 || constraintNumber > numConstraints)
			{
				Console.WriteLine("Error: Invalid constraint number.");
				return;
			}
			int rowIndex = constraintNumber - 1;

			// Prompt the user for the new value
			Console.Write("\nEnter the new value for the selected cell: ");
			if (!double.TryParse(Console.ReadLine(), out double newValue))
			{
				Console.WriteLine("Error: Invalid value.");
				return;
			}

			// Update the N matrix
			N[rowIndex, columnIndex] = newValue;

			// Recalculate matrices
			var updatedInitialTable = (double[,])initialTable.Clone();
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < nonBasicVariableIndices.Length; j++)
				{
					updatedInitialTable[i + 1, nonBasicVariableIndices[j]] = N[i, j];
				}
			}

			CreateMatrices(updatedInitialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Print updated matrices
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table (not implemented)
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);

			// Calculate allowable increase and decrease
			double[] delta = new double[numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				delta[i] = 0;
				for (int j = 0; j < nonBasicVariableIndices.Length; j++)
				{
					delta[i] += N[i, j] * B_inv[i, columnIndex];
				}
			}

			double lowerBound = double.NegativeInfinity;
			double upperBound = double.PositiveInfinity;

			for (int i = 0; i < delta.Length; i++)
			{
				if (delta[i] > 0)
				{
					upperBound = Math.Min(upperBound, cBvB_inv[i] / delta[i]);
				}
				else if (delta[i] < 0)
				{
					lowerBound = Math.Max(lowerBound, cBvB_inv[i] / delta[i]);
				}
			}
			Console.WriteLine($"\nAllowable increase: {(upperBound == double.PositiveInfinity ? "∞" : upperBound.ToString())}");
			Console.WriteLine($"\nAllowable decrease: {(lowerBound == double.NegativeInfinity ? "-∞" : lowerBound.ToString())}");
		}

		public void BasicColumnVariableChange(AlgorithmResults results)
		{
			if (results == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = results.InitialTable;
			double[,] finalTable = results.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1; // exclude RHS
			int numConstraints = initialTable.GetLength(0) - 1; // exclude Objective Function row

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			// Create matrices based on the initial setup
			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Display B matrix
			Console.WriteLine("\nB Matrix:");
			PrintMatrixDouble2DArray(B, basicVariableIndices);

			// Prompt user to select the basic variable to change
			Console.Write("\nEnter the basic variable to change (e.g., X2): ");
			string variableInput = Console.ReadLine();
			int variableIndex = int.Parse(variableInput.Substring(1)) - 1; // Assumes X1, X2, etc.

			// Get the index of the selected variable in the B matrix
			int basicVariableIndex = Array.IndexOf(basicVariableIndices, variableIndex);
			if (basicVariableIndex == -1)
			{
				Console.WriteLine("Error: Invalid basic variable.");
				return;
			}

			// Prompt user to select the constraint number
			Console.Write("\nEnter the constraint number to change (e.g., 1, 2, ...): ");
			if (!int.TryParse(Console.ReadLine(), out int constraintNumber) || constraintNumber < 1 || constraintNumber > numConstraints)
			{
				Console.WriteLine("Error: Invalid constraint number.");
				return;
			}

			int constraintIndex = constraintNumber - 1;

			// Prompt user for the new value
			Console.Write("\nEnter the new value for the selected cell: ");
			if (!double.TryParse(Console.ReadLine(), out double newValue))
			{
				Console.WriteLine("Error: Invalid value.");
				return;
			}

			// Update the B matrix with the new value
			B[constraintIndex, basicVariableIndex] = newValue;

			// Recalculate matrices using the updated B matrix
			var updatedInitialTable = (double[,])initialTable.Clone();
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < basicVariableIndices.Length; j++)
				{
					updatedInitialTable[i + 1, basicVariableIndices[j]] = B[i, j];
				}
			}

			// Recalculate matrices
			CreateMatrices(updatedInitialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Print updated matrices
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table (not implemented)
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);

			// Calculate allowable increase and decrease
			double[] delta = new double[numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				delta[i] = 0;
				for (int j = 0; j < basicVariableIndices.Length; j++)
				{
					delta[i] += N[i, j] * B_inv[i, basicVariableIndex];
				}
			}

			double lowerBound = double.NegativeInfinity;
			double upperBound = double.PositiveInfinity;

			for (int i = 0; i < delta.Length; i++)
			{
				if (delta[i] > 0)
				{
					upperBound = Math.Min(upperBound, cBvB_inv[i] / delta[i]);
				}
				else if (delta[i] < 0)
				{
					lowerBound = Math.Max(lowerBound, cBvB_inv[i] / delta[i]);
				}
			}
			Console.WriteLine($"\nAllowable increase: {(upperBound == double.PositiveInfinity ? "∞" : upperBound.ToString())}");
			Console.WriteLine($"\nAllowable decrease: {(lowerBound == double.NegativeInfinity ? "-∞" : lowerBound.ToString())}");
		}

		public void SensitivityMatrices(AlgorithmResults lastResults)
		{
			if (lastResults == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = lastResults.InitialTable;
			double[,] finalTable = lastResults.FinalTable;

			numVariables = initialTable.GetLength(1) - 1; // excluding RHS
			numConstraints = initialTable.GetLength(0) - 1; // excluding Objective Function

			// Identify basic and non-basic variables
			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			// Create matrices
			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Create positions for all variables
			variablePositions = new (int, int, bool)[numVariables];

			// Assign positions for basic variables
			for (int i = 0; i < basicVariableIndices.Length; i++)
			{
				variablePositions[basicVariableIndices[i]] = (0, i, true); // Basic variables in Cbv
			}

			// Assign positions for non-basic variables
			for (int i = 0; i < nonBasicVariableIndices.Length; i++)
			{
				variablePositions[nonBasicVariableIndices[i]] = (0, i, false); // Non-basic variables in nCbv
			}

			// Print matrices
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Display new Optimal Table
			Console.WriteLine("\nNew Optimal Table:");
			DisplayOptimalTable(numVariables, numConstraints, initialTable, B_inv, cBvB_inv, rhs, nCbv, cBv, variablePositions);
		}

		public void CreateMatrices(double[,] initialTable, int[] basicVariableIndices, int[] nonBasicVariableIndices, int numConstraints)
		{
			// Create Cbv matrix
			cBv = new double[basicVariableIndices.Length];
			for (int i = 0; i < basicVariableIndices.Length; i++)
			{
				cBv[i] = initialTable[0, basicVariableIndices[i]];
			}

			// Create nCbv matrix with non-negative values
			nCbv = new double[nonBasicVariableIndices.Length];
			for (int i = 0; i < nonBasicVariableIndices.Length; i++)
			{
				nCbv[i] = Math.Max(0, initialTable[0, nonBasicVariableIndices[i]]);
			}

			// Create B matrix
			B = new double[numConstraints, numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < numConstraints; j++)
				{
					B[i, j] = initialTable[i + 1, basicVariableIndices[j]];
				}
			}

			// Create N matrix
			N = new double[numConstraints, nonBasicVariableIndices.Length];
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < nonBasicVariableIndices.Length; j++)
				{
					N[i, j] = initialTable[i + 1, nonBasicVariableIndices[j]];
				}
			}

			// Compute the B inverse matrix matrix and cBv * B_inv
			B_inv = Inverse(B);
			cBvB_inv = Multiply(cBv, B_inv);

			// RHS matrix
			rhs = new double[numConstraints];
			for (int i = 0; i < numConstraints; i++)
			{
				rhs[i] = initialTable[i + 1, initialTable.GetLength(1) - 1];
			}

			// Convert rhs to a 2D column matrix
			var rhsMatrix = Matrix<double>.Build.DenseOfColumnArrays(rhs.Select(x => new[] { x }).ToArray());
		}

		public void PrintMatrices(int[] basicVariableIndices, int[] nonBasicVariableIndices)
		{
			Console.WriteLine("\nCbv Matrix:");
			PrintMatrixDoubleArray(cBv, basicVariableIndices);

			Console.WriteLine("\nnCbv Matrix:");
			PrintMatrixDoubleArray(nCbv, nonBasicVariableIndices);

			Console.WriteLine("\nB Matrix:");
			PrintMatrixDouble2DArray(B, basicVariableIndices);

			Console.WriteLine("\nN Matrix:");
			PrintMatrixDouble2DArray(N, nonBasicVariableIndices);

			Console.WriteLine("\nB Inverse Matrix:");
			PrintMatrixDouble2DArray(B_inv, basicVariableIndices);

			Console.WriteLine("\nCbv * B Inverse Matrix:");
			PrintMatrixDoubleArray(cBvB_inv, basicVariableIndices);

			Console.WriteLine("\nRHS Matrix:");
			PrintRHSMatrix(rhs);
		}

		public int[] GetBasicVariableIndices(double[,] finalTable, int numVariables, int numConstraints)
		{
			var basicVariables = new int[numConstraints];
			for (int j = 0; j < numConstraints; j++)
			{
				for (int i = 0; i < numVariables; i++)
				{
					if (finalTable[j + 1, i] == 1)
					{
						basicVariables[j] = i;
						break;
					}
				}
			}
			return basicVariables;
		}

		private double[,] Inverse(double[,] matrix)
		{
			var mat = Matrix<double>.Build.DenseOfArray(matrix);
			var matInv = mat.Inverse();
			return matInv.ToArray();
		}

		private double[] Multiply(double[] vector, double[,] matrix)
		{
			int rows = matrix.GetLength(0);
			int cols = matrix.GetLength(1);
			double[] result = new double[rows];

			for (int i = 0; i < rows; i++)
			{
				result[i] = 0;
				for (int j = 0; j < cols; j++)
				{
					result[i] += vector[j] * matrix[i, j];
				}
			}
			return result;
		}

		private double[] MultiplyColumn(double[] vector, double[] matrix)
		{
			if (vector.Length != matrix.Length)
			{
				throw new ArgumentException("Vector and matrix must have the same length for multiplication.");
			}

			double[] result = new double[vector.Length];
			for (int i = 0; i < vector.Length; i++)
			{
				result[i] = vector[i] * matrix[i];
			}
			return result;
		}

		private void DisplayOptimalTable(int numVariables, int numConstraints, double[,] initialTable, double[,] B_inv, double[] cBvB_inv, double[] rhs, double[] nCbv, double[] cBv, (int, int, bool)[] variablePositions)
		{
			// Step 1: Calculate the Objective Function variable values
			double[] optimalObjectiveValues = new double[numVariables];
			for (int i = 0; i < numVariables; i++)
			{
				double originalObjectiveValue = 0;

				// Retrieve the stored position and matrix type
				var (rowIndex, colIndex, isBasic) = variablePositions[i];

				// Get the original objective value based on the matrix type
				if (isBasic)
				{
					originalObjectiveValue = cBv[colIndex];
				}
				else
				{
					originalObjectiveValue = nCbv[colIndex];
				}

				double[] columnVector = new double[numConstraints];
				for (int j = 0; j < numConstraints; j++)
				{
					columnVector[j] = initialTable[j + 1, i];
				}

				double[] calculatedValues = MultiplyColumn(cBvB_inv, columnVector);
				optimalObjectiveValues[i] = calculatedValues.Sum() - originalObjectiveValue;
			}

			// Step 2: Calculate each variable's constraint column values
			double[,] optimalConstraintValues = new double[numConstraints, numVariables];
			for (int i = 0; i < numVariables; i++)
			{
				double[] columnVector = new double[numConstraints];
				for (int j = 0; j < numConstraints; j++)
				{
					columnVector[j] = initialTable[j + 1, i];
				}

				double[] calculatedValues = MultiplyBB(B_inv, columnVector);
				for (int j = 0; j < numConstraints; j++)
				{
					optimalConstraintValues[j, i] = calculatedValues[j];
				}
			}

			// Step 3: Calculate each constraint's RHS values
			double[] optimalRHSValues = MultiplyBB(B_inv, rhs);

			// Step 4: Calculate the Z-value (Objective function's RHS value)
			double zValue = CalculateObjectiveValue(cBvB_inv, rhs);

			// Populate and display the new Optimal Table
			Console.WriteLine("|--------------------------------------------------------------------|");
			Console.WriteLine("| t-Optimal Table     |   X1   |   X2   |   X3   |   X4   |   RHS    |");
			Console.WriteLine("|--------------------------------------------------------------------|");

			Console.Write("| OBJECTIVE FUNCTION  |");
			for (int i = 0; i < numVariables; i++)
			{
				Console.Write(" {0,6:F2} |", optimalObjectiveValues[i].ToString("0.###").PadLeft(6));
			}
			Console.WriteLine(" {0,8:F3} |", zValue.ToString("0.###").PadLeft(8));
			Console.WriteLine("|--------------------------------------------------------------------|");

			for (int i = 0; i < numConstraints; i++)
			{
				Console.Write("| CONSTRAINT {0}       |", (i + 1).ToString().PadLeft(2));
				for (int j = 0; j < numVariables; j++)
				{
					Console.Write(" {0,6:F2} |", optimalConstraintValues[i, j].ToString("0.###").PadLeft(6));
				}
				Console.WriteLine(" {0,8:F3} |", optimalRHSValues[i].ToString("0.###").PadLeft(8));
			}
			Console.WriteLine("|--------------------------------------------------------------------|");
		}


//Shadow Price calculations and its helper methods
		public void ShadowPrices(AlgorithmResults lastResults)
		{
			if (lastResults == null)
			{
				Console.WriteLine("Error: No model provided.");
				return;
			}

			double[,] initialTable = lastResults.InitialTable;
			double[,] finalTable = lastResults.FinalTable;

			int numVariables = initialTable.GetLength(1) - 1; // exclude RHS
			int numConstraints = initialTable.GetLength(0) - 1; // exclude Objective Function row

			int[] basicVariableIndices = GetBasicVariableIndices(finalTable, numVariables, numConstraints);
			int[] nonBasicVariableIndices = Enumerable.Range(0, numVariables).Except(basicVariableIndices).ToArray();

			// Create matrices
			CreateMatrices(initialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Calculate the original z-value
			double originalZValue = CalculateObjectiveValue(cBvB_inv, rhs);

			// Display current RHS values
			Console.WriteLine("\nCurrent RHS values:");
			for (int i = 0; i < rhs.Length; i++)
			{
				Console.WriteLine($"Constraint {i + 1}: {rhs[i]}");
			}

			// Prompt user to select which constraint value to change
			Console.Write("\nEnter the constraint number you want to change (e.g., 1, 2, ...): ");
			if (!int.TryParse(Console.ReadLine(), out int constraintNumber) || constraintNumber < 1 || constraintNumber > rhs.Length)
			{
				Console.WriteLine("Error: Invalid constraint number.");
				return;
			}

			// Get index of the selected constraint
			int constraintIndex = constraintNumber - 1;

			// Add 1 to the constraint value selected
			double originalConstraintValue = rhs[constraintIndex];
			double updatedConstraintValue = originalConstraintValue + 1;

			// Update the RHS matrix at the selected index with the new value
			rhs[constraintIndex] = updatedConstraintValue;

			// Update the RHS values in the initial table
			var updatedInitialTable = (double[,])initialTable.Clone();
			for (int i = 0; i < numConstraints; i++)
			{
				updatedInitialTable[i + 1, numVariables] = rhs[i];
			}

			// Recreate matrices with updated initial table
			CreateMatrices(updatedInitialTable, basicVariableIndices, nonBasicVariableIndices, numConstraints);

			// Print updated matrices
			PrintMatrices(basicVariableIndices, nonBasicVariableIndices);

			// Calculate the new z-value
			double newZValue = CalculateObjectiveValue(cBvB_inv, rhs);

			// Compute Shadow Price
			double shadowPrice = newZValue - originalZValue;
			Console.WriteLine($"\nShadow Price for Constraint {constraintNumber}: {newZValue} - {originalZValue} = {shadowPrice}");
		}

		private static double CalculateObjectiveValue(double[] cBvB_inv, double[] rhs)
		{
			if (cBvB_inv == null || rhs == null)
			{
				throw new InvalidOperationException("Matrices have not been initialized properly.");
			}

			// Ensure both vectors have the same length
			if (cBvB_inv.Length != rhs.Length)
			{
				throw new InvalidOperationException("Length of cBv * B_inv vector and RHS vector must be the same.");
			}

			double zValue = 0;

			// Calculate the Z value
			for (int i = 0; i < cBvB_inv.Length; i++)
			{
				zValue += cBvB_inv[i] * rhs[i];
			}
			return zValue;
		}


//Adding Constraints method and its helper methods
		public void AddConstraint(AlgorithmResults lastResults)
		{
			// Retrieve the final table from lastResults
			double[,] finalTable = lastResults.FinalTable;

			// Call SensitivityMatrices() to display the matrices and original optimal table
			SensitivityMatrices(lastResults);

			// Determine the number of constraints and columns
			int numConstraints = finalTable.GetLength(0);
			int numColumns = finalTable.GetLength(1);

			// Create a new row matrix for the constraint
			double[] newConstraintRow = new double[numColumns];

			// Prompt the user for new constraint values
			Console.WriteLine("\nEnter the new constraint values for each column (including RHS):");
			for (int i = 0; i < numColumns; i++)
			{
				if (i != numColumns - 1)
				{
					Console.Write($"Column {i + 1}: ");
					newConstraintRow[i] = Convert.ToDouble(Console.ReadLine());
				}
				else
				{
					Console.Write("RHS: ");
					newConstraintRow[i] = Convert.ToDouble(Console.ReadLine());
				}
			}

			// Insert the new constraint row into the final table
			double[,] updatedTable = new double[numConstraints + 1, numColumns];
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < numColumns; j++)
				{
					updatedTable[i, j] = finalTable[i, j];
				}
			}
			for (int j = 0; j < numColumns; j++)
			{
				updatedTable[numConstraints, j] = newConstraintRow[j];
			}

			// Display the updated table with the new constraint
			DisplayTable(updatedTable, "\nUpdated Optimal Table with New Constraint");

			// Store the updated tables from Scenario 1 and Scenario 2
			double[,] scenario1UpdatedTable = null;  // Initialize as null
			double[,] scenario2UpdatedTable = null;  // Initialize as null
			double multiplier = 0;
			double[] copiedConstraintRow = new double[numColumns];

			bool allBasicRestored = false;

			while (!allBasicRestored)
			{
				allBasicRestored = true;

				// Check each variable to see if it has turned from basic to non-basic
				for (int i = 0; i < numConstraints; i++)
				{
					if (scenario2UpdatedTable != null)
					{
						// Use Scenario 2's updated table if it's not null
						updatedTable = (double[,])scenario2UpdatedTable.Clone();

					}

					if (IsBasicVariable(i, finalTable) && !IsBasicVariable(i, updatedTable))
					{
						Console.WriteLine($"\nBasic variable X{i + 1} has become non-basic after adding the new constraint.");

						// Identify the constraint row containing "1" for the non-basic variable
						int constraintRowIndex = -1;
						for (int k = 0; k < numConstraints; k++)
						{
							if (finalTable[k, i] == 1)
							{
								constraintRowIndex = k;
								break;
							}
						}

						if (constraintRowIndex == -1)
						{
							Console.WriteLine($"\nNo constraint row contains a '1' for X{i + 1}. Operation cannot proceed.");
							continue;
						}

						// Display the copied constraint and its values
						Console.WriteLine($"\nCopied Constraint {constraintRowIndex} Values: ");
						for (int j = 0; j < numColumns; j++)
						{
							Console.Write($"{finalTable[constraintRowIndex, j]} ");
						}
						Console.WriteLine();

						// Scenario 1: If the value that made the variable non-basic is 1
						if (newConstraintRow[i] == 1)
						{
							Console.WriteLine($"\nSubtracting the new constraint from constraint {constraintRowIndex + 1}:");
							for (int j = 0; j < numColumns; j++)
							{
								updatedTable[numConstraints, j] = finalTable[constraintRowIndex, j] - newConstraintRow[j];
							}

							// If Scenario 1 was executed, store the result
							scenario1UpdatedTable = (double[,])updatedTable.Clone();
						}
						// Scenario 2: If the value that made the variable non-basic is not 1
						else
						{
							// Check if Scenario 1's table has values
							if (scenario1UpdatedTable != null)
							{
								finalTable = (double[,])scenario1UpdatedTable.Clone();
								multiplier = scenario1UpdatedTable[numConstraints, i]; // Get the multiplier from the last row
								
								// Update newConstraintRow with the values from the last row of finalTable
								for (int j = 0; j < numColumns; j++)
								{
									newConstraintRow[j] = finalTable[numConstraints, j];
								}
							}
							else
							{
								multiplier = newConstraintRow[i];
							}

							// Copy the identified constraint row
							for (int j = 0; j < numColumns; j++)
							{
								copiedConstraintRow[j] = finalTable[constraintRowIndex, j];
							}

							Console.WriteLine($"\nMultiplying constraint {constraintRowIndex} by {multiplier}:");

							// Multiply the copied constraint row by the multiplier
							for (int j = 0; j < numColumns; j++)
							{
								copiedConstraintRow[j] *= multiplier;
							}

							Console.WriteLine($"\nModified Constraint {constraintRowIndex}");
							for (int m = 0; m < copiedConstraintRow.Length; m++)
							{
								Console.Write($"{copiedConstraintRow[m]} ");
							}
							Console.WriteLine();

							// Subtract the new constraint row from the adjusted copied constraint row
							for (int j = 0; j < numColumns; j++)
							{
								updatedTable[numConstraints, j] = copiedConstraintRow[j] - newConstraintRow[j];
							}

							Console.WriteLine("\nnewConstraintRow values:");
							for (int m = 0; m < newConstraintRow.Length; m++)
							{
								Console.Write($"{newConstraintRow[m]} ");
							}
							Console.WriteLine();

							// If Scenario 2 was executed, store the result
							scenario2UpdatedTable = (double[,])updatedTable.Clone();
						}

						// Display the updated table
						DisplayTable(updatedTable, $"\nUpdated Table after making X{i + 1} basic again");

						allBasicRestored = false;
						break;  // Exit the for loop to recheck all variables
					}
				}
			}

			// Final check if all basic variables are restored and RHS value is non-negative
			if (IsBasicAfterOperations(updatedTable, numConstraints) && updatedTable[numConstraints, numColumns - 1] >= 0)
			{
				Console.WriteLine("This new activity is Optimal.");
			}
			else if (updatedTable[numConstraints, numColumns - 1] < 0)
			{
				Console.WriteLine("\nRHS value is negative. Solving using Dual Simplex to find the optimal solution...");
				double[,] finalOptimalTable = DualSolve(updatedTable, true);  // Pass the isMax argument
				DisplayTable(finalOptimalTable, "\nFinal Optimal Table After Dual Simplex");
				Console.WriteLine("This new activity is Optimal.");
			}
		}

		private bool IsBasicAfterOperations(double[,] table, int newConstraintIndex)
		{
			// Check if all original basic variables are still basic after operations
			for (int i = 0; i < newConstraintIndex; i++)
			{
				if (!IsBasicVariable(i, table))
				{
					return false;
				}
			}
			return true;
		}

		private bool IsBasicVariable(int variableIndex, double[,] table)
		{
			// Determine if the variable is basic by checking if there's a single "1" in its column
			int count = 0;
			for (int i = 0; i < table.GetLength(0); i++)
			{
				if (table[i, variableIndex] == 1)
				{
					count++;
				}
				else if (table[i, variableIndex] != 0)
				{
					return false;
				}
			}
			return count == 1;
		}

		public double[,] DualSolve(double[,] table, bool isMax)
		{
			// List to store the history of tableau changes
			List<double[,]> tableauHistory = new List<double[,]>();

			// Phase 1: Handle dual feasibility by ensuring no negative RHS values.
			while (HasNegativeRHS(table))
			{
				int pivotRow = SelectPivotRowForDual(table);
				int pivotColumn = SelectPivotColumnForDual(table, pivotRow);

				// If no valid pivot column is found, return the current table as the final one.
				if (pivotColumn == -1)
				{
					return table;
				}

				// Perform pivot operation to update the table.
				PerformPivoting(table, pivotRow, pivotColumn);
				tableauHistory.Add((double[,])table.Clone());
			}

			// Phase 2: Optimize the objective function.
			while (HasNegativeObjective(table, isMax))
			{
				int pivotColumn = SelectPivotColumnObjective(table, isMax);
				int pivotRow = SelectPivotRowForObjective(table, pivotColumn);

				// If no valid pivot row is found, return the current table as the final one.
				if (pivotRow == -1)
				{
					return table;
				}

				// Perform pivot operation to update the table.
				PerformPivoting(table, pivotRow, pivotColumn);
				tableauHistory.Add((double[,])table.Clone());
			}

			// Return the final optimized table.
			return table;
		}

		private int SelectPivotRowForDual(double[,] table)
		{
			// Selects the pivot row based on the negative RHS value (excluding the objective function row).
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double mostNegativeRHS = 0;

			for (int i = 1; i < rows; i++)
			{
				double rhsValue = table[i, table.GetLength(1) - 1];
				if (rhsValue < mostNegativeRHS)
				{
					mostNegativeRHS = rhsValue;
					pivotRow = i;
				}
			}
			return pivotRow;
		}

		private int SelectPivotColumnForDual(double[,] table, int pivotRow)
		{
			// Selects the pivot column based on the smallest absolute ratio test for the pivot row.
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double minRatio = double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				double columnValue = table[pivotRow, j];
				if (columnValue < 0)
				{
					double ratio = Math.Abs(table[0, j] / columnValue);
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotColumn = j;
					}
				}
			}
			return pivotColumn;
		}

		private bool HasNegativeRHS(double[,] table)
		{
			// Checks if there are negative RHS values (excluding the objective function row).
			int rows = table.GetLength(0);
			int columns = table.GetLength(1) - 1;
			for (int i = 1; i < rows; i++)
			{
				if (table[i, columns] < 0)
				{
					return true;
				}
			}
			return false;
		}

		private void PerformPivoting(double[,] table, int pivotRow, int pivotColumn)
		{
			// Performs the pivot operation to update the simplex table.
			int rows = table.GetLength(0);
			int columns = table.GetLength(1);

			// Normalize the pivot row.
			double pivotElement = table[pivotRow, pivotColumn];
			for (int j = 0; j < columns; j++)
			{
				table[pivotRow, j] /= pivotElement;
			}

			// Update other rows based on the pivot row.
			for (int i = 0; i < rows; i++)
			{
				if (i != pivotRow)
				{
					double rowFactor = table[i, pivotColumn];
					for (int j = 0; j < columns; j++)
					{
						table[i, j] -= rowFactor * table[pivotRow, j];
					}
				}
			}
		}

		private bool HasNegativeObjective(double[,] table, bool isMax)
		{
			// Checks if there are negative coefficients in the objective function row.
			int columns = table.GetLength(1) - 1;
			for (int j = 0; j < columns; j++)
			{
				if (isMax && table[0, j] < 0) return true;
				if (!isMax && table[0, j] > 0) return true;
			}
			return false;
		}

		private int SelectPivotColumnObjective(double[,] table, bool isMax)
		{
			// Selects the pivot column based on the objective function.
			int columns = table.GetLength(1) - 1;
			int pivotColumn = -1;
			double largestValue = isMax ? 0 : double.MaxValue;

			for (int j = 0; j < columns; j++)
			{
				if (isMax && table[0, j] < largestValue)
				{
					largestValue = table[0, j];
					pivotColumn = j;
				}
				else if (!isMax && table[0, j] > largestValue)
				{
					largestValue = table[0, j];
					pivotColumn = j;
				}
			}
			return pivotColumn;
		}

		private int SelectPivotRowForObjective(double[,] table, int pivotColumn)
		{
			// Selects the pivot row based on the minimum ratio test for the objective function.
			int rows = table.GetLength(0);
			int pivotRow = -1;
			double minRatio = double.MaxValue;

			for (int i = 1; i < rows; i++)
			{
				double rhsValue = table[i, table.GetLength(1) - 1];
				double columnValue = table[i, pivotColumn];
				if (columnValue > 0)
				{
					double ratio = rhsValue / columnValue;
					if (ratio < minRatio)
					{
						minRatio = ratio;
						pivotRow = i;
					}
				}
			}
			return pivotRow;
		}


//Adding Activity method and its helper methods
		public void AddActivity(AlgorithmResults lastResults)
		{
			// Retrieve the final table from lastResults
			double[,] finalTable = lastResults.FinalTable;

			// Call SensitivityMatrices() to display the matrices and original optimal table
			SensitivityMatrices(lastResults);

			// Determine the number of constraints and columns
			numConstraints = finalTable.GetLength(0);
			numColumns = finalTable.GetLength(1);

			// Create a new column matrix
			double[,] newColumnMatrix = new double[numConstraints, 1];

			// Prompt the user for the new objective function value
			Console.Write("\nEnter the new objective function value for the new column: ");
			double newObjectiveFunctionValue = Convert.ToDouble(Console.ReadLine());
			newColumnMatrix[0, 0] = newObjectiveFunctionValue;

			// Prompt the user for new column values for each constraint
			Console.WriteLine("\nEnter the new column values for each constraint:");
			for (int i = 1; i < numConstraints; i++)
			{
				Console.Write($"Constraint {i}: ");
				newColumnMatrix[i, 0] = Convert.ToDouble(Console.ReadLine());
			}

			// Calculate the new objective function row value for the new column in the new optimal table
			double[] calculatedObjectiveRow = new double[numColumns];
			double sum = 0;
			for (int i = 0; i < numConstraints - 1; i++)
			{
				sum += cBvB_inv[i] * newColumnMatrix[i + 1, 0];
			}
			calculatedObjectiveRow[0] = sum - newObjectiveFunctionValue;

			// Calculate the new column values for the new optimal table (excluding the objective function row)
			double[] newColumnValuesCalculated = new double[numConstraints - 1];
			for (int i = 0; i < numConstraints - 1; i++)
			{
				sum = 0;
				for (int j = 0; j < numConstraints - 1; j++)
				{
					sum += B_inv[i, j] * newColumnMatrix[j + 1, 0];
				}
				newColumnValuesCalculated[i] = sum;
			}

			// Create a new matrix (matrix 2) to store the calculated values
			double[,] newMatrix2 = new double[numConstraints, numColumns];
			newMatrix2[0, 0] = calculatedObjectiveRow[0];
			for (int i = 1; i < numConstraints; i++)
			{
				newMatrix2[i, 0] = newColumnValuesCalculated[i - 1];
			}

			// Insert the new matrix 2 into the original optimal table before the RHS column
			double[,] updatedTable = new double[numConstraints, numColumns + 1];
			for (int i = 0; i < numConstraints; i++)
			{
				for (int j = 0; j < numColumns - 1; j++)
				{
					updatedTable[i, j] = finalTable[i, j];
				}
				updatedTable[i, numColumns - 1] = newMatrix2[i, 0]; // Insert new column before RHS
				updatedTable[i, numColumns] = finalTable[i, numColumns - 1]; // Copy RHS column
			}

			// Display the updated optimal table using DisplayTable method
			Console.WriteLine("\n");
			DisplayTable(updatedTable, "Updated Optimal Table with New Column");

			// Solve using Primal Simplex to obtain the final optimal table
			double[,] finalOptimalTable = Solve(updatedTable);
			DisplayTable(finalOptimalTable, "\nNew Optimal Table after solving");

			Console.WriteLine("\nThis new activity is feasible as it is being produced.");
		}

		static void DisplayTable(double[,] table, string tableName, List<string> slackVariables = null, List<string> excessVariables = null)
		{
			if (table == null)
			{
				Console.WriteLine($"Error: {tableName} is null.");
				return;
			}

			int rows = table.GetLength(0);
			int cols = table.GetLength(1);

			// Determine maximum width for each column
			int[] columnWidths = new int[cols];
			for (int j = 0; j < cols; j++)
			{
				columnWidths[j] = 0;
				for (int i = 0; i < rows; i++)
				{
					// Determine if the value is an integer or a decimal
					string formattedValue = Math.Abs(table[i, j]) % 1 == 0 ? table[i, j].ToString("0") : table[i, j].ToString("F3");
					int length = formattedValue.Length;
					if (length > columnWidths[j])
					{
						columnWidths[j] = length;
					}
				}
				// Add extra space for formatting
				columnWidths[j] += 2; // Adjust as needed for padding
			}

			// Add headers to column widths for the final row
			string[] headers = new string[cols];
			for (int j = 0; j < cols - 1; j++)
			{
				headers[j] = $"X{j + 1}";
			}
			headers[cols - 1] = "RHS"; // Adjust header as needed

			// Add slack and excess variable headers if present
			if (slackVariables != null && slackVariables.Count > 0)
			{
				headers = headers.Concat(slackVariables).ToArray();
			}
			if (excessVariables != null && excessVariables.Count > 0)
			{
				headers = headers.Concat(excessVariables).ToArray();
			}

			// Used Padding to ensure the table columns are even and aligned
			string headerLine = "| " + string.Join(" | ", headers.Select((header, index) => header.PadRight(columnWidths[index])));
			string separatorLine = "|-" + string.Join("-|-", columnWidths.Select(width => new string('-', width))) + "-|-";

			Console.WriteLine($"{tableName}:");
			Console.WriteLine(separatorLine);
			Console.WriteLine(headerLine);
			Console.WriteLine(separatorLine);

			// Display table rows
			for (int i = 0; i < rows; i++)
			{
				Console.Write("| ");
				for (int j = 0; j < cols; j++)
				{
					// Format value based on whether it's an integer or decimal
					string formattedValue = Math.Abs(table[i, j]) % 1 == 0 ? table[i, j].ToString("0") : table[i, j].ToString("F3");
					// Convert negative zero to positive zero
					formattedValue = formattedValue.Replace("-0", "0");
					Console.Write(formattedValue.PadLeft(columnWidths[j]) + " | ");
				}
				Console.WriteLine();
				Console.WriteLine(separatorLine);
			}
		}

		public double[,] Solve(double[,] table)
		{
			// Create a new result object to store the output.
			var result = new PrimalSimplexResult { FinalTable = table };

			// Iterate until an optimal solution is found or the problem is identified as infeasible.
			while (!IsOptimal(result.FinalTable) && !IsInfeasible(result.FinalTable))
			{
				// Select the entering variable (column) for the pivot operation.
				int entering = SelectEnteringVariable(result.FinalTable);

				// Select the leaving variable (row) for the pivot operation.
				int leaving = SelectLeavingVariable(result.FinalTable, entering);

				// If no valid leaving variable is found, the problem is unbounded.
				if (leaving == -1)
				{
					result.SolutionStatus = "Unbounded";
					break;
				}

				// Perform the pivot operation to update the table.
				Pivot(result.FinalTable, entering, leaving);
			}

			// Set the solution status based on the final table state.
			if (IsOptimal(result.FinalTable))
			{
				result.SolutionStatus = "Optimal";
			}
			else if (IsInfeasible(result.FinalTable))
			{
				result.SolutionStatus = "Infeasible";
			}

			// Return the final optimal table.
			return result.FinalTable;
		}

		private static bool IsOptimal(double[,] table)
		{
			int numCols = table.GetLength(1);
			for (int j = 0; j < numCols - 1; j++)
			{
				if (table[0, j] < 0)
				{
					return false;
				}
			}
			return true;
		}

		private bool IsInfeasible(double[,] table)
		{
			// Checks if the current table represents an infeasible solution.
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			for (int i = 1; i < numRows; i++)
			{
				if (table[i, numCols - 1] < 0)
				{
					return true;
				}
			}
			return false;
		}

		private int SelectEnteringVariable(double[,] table)
		{
			// Selects the entering variable (column) for the pivot operation based on the most negative value in the objective row.
			int numCols = table.GetLength(1);
			int entering = -1;
			double minValue = 0;

			for (int j = 0; j < numCols - 1; j++)
			{
				if (table[0, j] < minValue)
				{
					minValue = table[0, j];
					entering = j;
				}
			}
			return entering;
		}

		private int SelectLeavingVariable(double[,] table, int entering)
		{
			// Selects the leaving variable (row) for the pivot operation based on the minimum ratio test.
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			double minRatio = double.MaxValue;
			int leaving = -1;

			for (int i = 1; i < numRows; i++)
			{
				if (table[i, entering] > 0)
				{
					double ratio = table[i, numCols - 1] / table[i, entering];
					if (ratio < minRatio)
					{
						minRatio = ratio;
						leaving = i;
					}
				}
			}

			return leaving;
		}

		private void Pivot(double[,] table, int entering, int leaving)
		{
			// Performs the pivot operation on the table.
			int numRows = table.GetLength(0);
			int numCols = table.GetLength(1);
			double pivotElement = table[leaving, entering];

			// Normalize the pivot row
			for (int j = 0; j < numCols; j++)
			{
				table[leaving, j] /= pivotElement;
			}

			// Update other rows
			for (int i = 0; i < numRows; i++)
			{
				if (i != leaving)
				{
					double multiplier = table[i, entering];
					for (int j = 0; j < numCols; j++)
					{
						table[i, j] -= multiplier * table[leaving, j];
					}
				}
			}
		}

		private double[,] CloneMatrix(double[,] original)
		{
			// Creates a deep copy of the matrix.
			int rows = original.GetLength(0);
			int cols = original.GetLength(1);
			var clone = new double[rows, cols];

			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < cols; j++)
				{
					clone[i, j] = original[i, j];
				}
			}
			return clone;
		}


//Multiply various Matrices
		private double[] MultiplyBB(double[,] matrix, double[] vector)
		{
			int rows = matrix.GetLength(0);
			int cols = matrix.GetLength(1);

			if (vector.Length != cols)
			{
				throw new ArgumentException("Vector length must match the number of matrix columns.");
			}

			double[] result = new double[rows];
			for (int i = 0; i < rows; i++)
			{
				result[i] = 0;
				for (int j = 0; j < cols; j++)
				{
					result[i] += matrix[i, j] * vector[j];
				}
			}
			return result;
		}

		public double[] MultiplyObjectiveValue(double[] cBvB_inv, Matrix<double> newMatrix)
		{
			int rows = cBvB_inv.Length;
			int cols = newMatrix.ColumnCount;

			if (newMatrix.RowCount != rows)
			{
				throw new ArgumentException("Matrix row count must match the length of the cBvB_inv array.");
			}

			double[] result = new double[rows];
			for (int i = 0; i < rows; i++)
			{
				result[i] = 0;
				for (int j = 0; j < cols; j++)
				{
					result[i] += cBvB_inv[i] * newMatrix[j, 0];
				}
			}
			return result;
		}

		public double[] MultiplyMatrix(double[,] cBvB_inv, Matrix<double> newMatrix)
		{
			int rows = cBvB_inv.GetLength(0); // Number of rows in cBvB_inv
			int cols = cBvB_inv.GetLength(1); // Number of columns in cBvB_inv

			// Check if newMatrix has the same number of rows as columns in cBvB_inv
			if (newMatrix.RowCount != cols)
			{
				throw new ArgumentException("Matrix row count must match the number of matrix columns in cBvB_inv.");
			}

			double[] result = new double[rows];
			for (int i = 0; i < rows; i++)
			{
				result[i] = 0;
				for (int j = 0; j < cols; j++)
				{
					// Access newMatrix elements using newMatrix[j, 0]
					result[i] += cBvB_inv[i, j] * newMatrix[j, 0];
				}
			}
			return result;
		}

		private double[] MultiplyB(double[,] matrix, double[] vector)
		{
			int rows = matrix.GetLength(0);
			int cols = matrix.GetLength(1);

			if (vector.GetLength(0) != cols || vector.GetLength(1) != 1)
			{
				throw new ArgumentException("Matrix dimensions do not match for multiplication.");
			}

			double[] result = new double[rows];
			for (int i = 0; i < rows; i++)
			{
				result[i] = 0;
				for (int j = 0; j < cols; j++)
				{
					result[i] += matrix[i, j] * vector[j];
				}
			}
			return result;
		}


//Print various Matrices
		private void PrintMatrixDoubleArray(double[] array, int[] indices)
		{
			int width = 12; // Adjust the width to accommodate decimal formatting
			int numVariables = array.Length;

			// Create headings
			Console.WriteLine("|" + new string('-', width * numVariables + (numVariables - 1)) + "|");
			Console.WriteLine("|" + string.Join("|", indices.Select(i => $" X{i + 1}".PadRight(width))) + "|");
			Console.WriteLine("|" + new string('-', width * numVariables + (numVariables - 1)) + "|");

			// Print array values
			Console.WriteLine("|" + string.Join("|", array.Select(value => FormatValue(value).PadLeft(width))) + "|");
			Console.WriteLine("|" + new string('-', width * numVariables + (numVariables - 1)) + "|");
		}

		private void PrintMatrixDouble2DArray(double[,] matrix, int[] indices)
		{
			int width = 12; // Adjust the width to accommodate decimal formatting
			int cols = matrix.GetLength(1);

			// Create headings based on indices
			Console.WriteLine("|" + new string('-', width * cols + (cols - 1)) + "|");
			Console.WriteLine("|" + string.Join("|", indices.Select(i => $"X{i + 1}".PadRight(width))) + "|");
			Console.WriteLine("|" + new string('-', width * cols + (cols - 1)) + "|");

			for (int i = 0; i < matrix.GetLength(0); i++)
			{
				Console.WriteLine("|" + string.Join("|", Enumerable.Range(0, cols).Select(j => FormatValue(matrix[i, j]).PadRight(width))) + "|");
				Console.WriteLine("|" + new string('-', width * cols + (cols - 1)) + "|");
			}
		}

		private void PrintRHSMatrix(double[] rhs)
		{
			int width = 8; // Define the width for padding
			Console.WriteLine("|" + new string('-', width) + "|");
			foreach (var value in rhs)
			{
				Console.WriteLine($"|{value.ToString().PadLeft(width)}|");
				Console.WriteLine("|" + new string('-', width) + "|");
			}
		}


//Format displace to show 3 decimal places
		private string FormatValue(double value)
		{
			if (Math.Abs(value - Math.Round(value)) < 1e-10)
			{
				// If value is essentially an integer
				return value.ToString("0");
			}
			else
			{
				// If value is a decimal
				return value.ToString("0.###");
			}
		}
	}
}