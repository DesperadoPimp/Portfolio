﻿using Accord.Math;
using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linear_Programming_Project.Algorithms
{		
	public class DualityResult
	{
		public double[,] PrimalForm { get; set; }
		public double[,] DualForm { get; set; }
		public List<double[,]> TableauHistory { get; set; }
		public double[,] FinalTable { get; set; }
		public string SolutionStatus { get; set; }
	}

	internal class Duality
	{
		public DualityResult Solve(LinearProgramingModel model)
		{
			var dualModel = GenerateDualModel(model);
			var dualSimplex = new DualSimplex();
			var dualSimplexResult = dualSimplex.Solve(dualModel);

			var dualityResult = new DualityResult
			{
				PrimalForm = ConvertToMatrix(model),
				DualForm = ConvertToMatrix(dualModel),
				TableauHistory = dualSimplexResult.TableauHistory,
				FinalTable = dualSimplexResult.FinalTable,
				SolutionStatus = dualSimplexResult.SolutionStatus.ToString()
			};

			CheckStrongWeakDuality(dualityResult.FinalTable, dualSimplexResult);
			return dualityResult;
		}

		private LinearProgramingModel GenerateDualModel(LinearProgramingModel primalModel)
		{
			var dualModel = new LinearProgramingModel
			{
				Objective = primalModel.IsMaximization ? "min" : "max",
				ObjectiveCoefficients = new double[primalModel.RHS.Length],
				Constraints = new double[primalModel.ObjectiveCoefficients.Length, primalModel.RHS.Length],
				RHS = primalModel.ObjectiveCoefficients,
				Signs = new string[primalModel.ObjectiveCoefficients.Length],
				SignRestrictions = new string[primalModel.RHS.Length],
				IsMaximization = !primalModel.IsMaximization
			};

			for (int i = 0; i < primalModel.RHS.Length; i++)
			{
				dualModel.ObjectiveCoefficients[i] = primalModel.RHS[i];
			}

			for (int i = 0; i < primalModel.ObjectiveCoefficients.Length; i++)
			{
				for (int j = 0; j < primalModel.RHS.Length; j++)
				{
					dualModel.Constraints[j, i] = primalModel.Constraints[i, j];
				}
			}

			for (int i = 0; i < primalModel.RHS.Length; i++)
			{
				dualModel.Signs[i] = GetDualSign(primalModel.SignRestrictions[i], dualModel.IsMaximization);
			}

			for (int i = 0; i < primalModel.ObjectiveCoefficients.Length; i++)
			{
				dualModel.SignRestrictions[i] = GetDualSignRestriction(primalModel.Signs[i], primalModel.IsMaximization);
			}
			return dualModel;
		}

		private string GetDualSign(string primalSign, bool isDualMaximization)
		{
			if (primalSign == "-")
			{
				return isDualMaximization ? ">=" : "<=";
			}
			else if (primalSign == "+")
			{
				return isDualMaximization ? "<=" : ">=";
			}
			else
			{
				return "=";
			}
		}

		private string GetDualSignRestriction(string primalConstraintSign, bool isPrimalMaximization)
		{
			if (primalConstraintSign == ">=")
			{
				return isPrimalMaximization ? "-" : "+";
			}
			else if (primalConstraintSign == "<=")
			{
				return isPrimalMaximization ? "+" : "-";
			}
			else
			{
				return "urs";
			}
		}

		private double[,] ConvertToMatrix(LinearProgramingModel model)
		{
			var numRows = model.Constraints.GetLength(0);
			var numCols = model.Constraints.GetLength(1);
			var matrix = new double[numRows, numCols + 1];

			for (int i = 0; i < numRows; i++)
			{
				for (int j = 0; j < numCols; j++)
				{
					matrix[i, j] = model.Constraints[i, j];
				}
				matrix[i, numCols] = model.RHS[i];
			}
			return matrix;
		}

		private void CheckStrongWeakDuality(double[,] finalDualTable, DualSimplexResult primalSimplexResult)
		{
			double primalZValue = Math.Round(primalSimplexResult.FinalTable[0, primalSimplexResult.FinalTable.GetLength(1) - 1], 3);
			double dualWValue = Math.Round(finalDualTable[0, finalDualTable.GetLength(1) - 1], 3);

			Console.WriteLine($"Primal optimal solution z = {primalZValue}");
			Console.WriteLine($"Dual optimal solution w = {dualWValue}");

			double dualityGap = primalZValue - dualWValue;

			if (dualityGap == 0)
			{
				Console.WriteLine("This model has a strong duality");
			}
			else
			{
				Console.WriteLine("This model has a weak duality");
			}
		}
	}
}