﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linear_Programming_Project.BusinessLogic
{
	/// <summary>
	/// The LinearProgramingModel class is a representation of a linear programming problem.
	/// It encapsulates key components of the model including the objective function, its coefficients, constraints, right-hand side values, and sign restrictions. 
	/// Additionally, it maintains bounds for the variables and flags to indicate the feasibility and boundedness of the model. 
	/// The class supports cloning, allowing for the creation of a shallow copy of the instance. T
	/// his class is designed to facilitate the solving and analysis of linear programming problems by providing a structured way to store and manage the necessary data.
	/// </summary>

	internal class LinearProgramingModel : ICloneable
	{
		// Represents the objective function of the linear programming model (e.g., "Maximize Z").
		public string Objective { get; set; }

		// Coefficients of the objective function. These are the values corresponding to the variables in the objective function.
		public double[] ObjectiveCoefficients { get; set; }

		// The matrix representing the constraints of the linear programming model. Each row corresponds to a constraint.
		public double[,] Constraints { get; set; }

		// Right-hand side values for the constraints, corresponding to the values on the right side of the inequality or equality.
		public double[] RHS { get; set; }

		// Sign restrictions for each constraint, such as "<=" or ">=". 
		public string[] Signs { get; set; }

		// Additional sign restrictions if needed for specific constraints.
		public string[] SignRestrictions { get; set; }

		// Lower bounds for the variables, specifying the minimum allowable values for each variable.
		public double[] LowerBound { get; set; }

		// Upper bounds for the variables, specifying the maximum allowable values for each variable.
		public double[] UpperBound { get; set; }

		// Flag indicating if the model is infeasible (i.e., no solution exists).
		public bool IsInfeasible { get; set; } = false;

		// Flag indicating if the model is feasible (i.e., a solution exists that satisfies all constraints).
		public bool IsFeasible { get; set; } = false;

		// Flag indicating if the model is unbounded (i.e., the objective function can increase indefinitely).
		public bool IsUnbounded { get; set; } = false;

		// Flag indicating if the objective function is a maximization problem (true) or minimization (false).
		public bool IsMaximization { get; set; }

		// Creates a shallow copy of the current instance of the LinearProgramingModel.
		public object Clone()
		{
			return MemberwiseClone();
		}
	}
}