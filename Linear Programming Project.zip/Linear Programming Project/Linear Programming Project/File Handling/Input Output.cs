﻿using Linear_Programming_Project.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linear_Programming_Project.File_Handling
{
	internal class Input_Output
	{
		public LinearProgramingModel ImportLPFile(string filePath)
		{
			try
			{
				var lines = File.ReadAllLines(filePath);
				return ParseFileData(lines);
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Error reading file: {ex.Message}");
				return null;
			}
		}

		private LinearProgramingModel ParseFileData(string[] lines)
		{
			var model = new LinearProgramingModel();
			if (lines.Length < 3)
			{
				throw new InvalidDataException("The input file is not in the expected format.");
			}

			// First line: objective function
			string[] objectiveParts = lines[0].Split(' ');
			model.Objective = objectiveParts[0];
			model.ObjectiveCoefficients = objectiveParts.Skip(1).Select(double.Parse).ToArray();

			// Constraints
			int constraintCount = lines.Length - 2; // Excluding the first and last lines
			model.Constraints = new double[constraintCount, model.ObjectiveCoefficients.Length];
			model.RHS = new double[constraintCount];
			model.Signs = new string[constraintCount];

			for (int i = 0; i < constraintCount; i++)
			{
				string[] constraintParts = lines[i + 1].Split(' ');

				// Parsing the coefficients
				for (int j = 0; j < model.ObjectiveCoefficients.Length; j++)
				{
					model.Constraints[i, j] = double.Parse(constraintParts[j]);
				}

				// Parsing the sign and RHS
				model.Signs[i] = constraintParts[model.ObjectiveCoefficients.Length];
				model.RHS[i] = double.Parse(constraintParts.Last().Replace("<=", "").Replace(">=", "").Replace("=", ""));
			}

			// Sign restrictions
			model.SignRestrictions = lines.Last().Split(' ');

			return model;
		}

		// Method to export results to file
		public void ExportResultsToFile(double[,] initialTable, List<double[,]> tableauHistory, double[,] finalTable, string solutionStatus)
		{
			try
			{
				using (StreamWriter sw = new StreamWriter("output.txt"))
				{
					// Export Initial Table
					sw.WriteLine("Initial Table:");
					WriteTableToFile(sw, initialTable);

					// Export Tableau History
					sw.WriteLine("\nTableau History:");
					foreach (var table in tableauHistory)
					{
						WriteTableToFile(sw, table);
					}

					// Export Final Table
					sw.WriteLine("\nFinal Table:");
					WriteTableToFile(sw, finalTable);

					// Export Solution Status
					sw.WriteLine($"\nSolution Status: {solutionStatus}");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Error writing to file: {ex.Message}");
			}
		}

		// Write a table to the file
		private void WriteTableToFile(StreamWriter sw, double[,] table)
		{
			int rows = table.GetLength(0);
			int cols = table.GetLength(1);

			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < cols; j++)
				{
					sw.Write($"{table[i, j],10:F3} ");
				}
				sw.WriteLine();
			}
		}
	}
}