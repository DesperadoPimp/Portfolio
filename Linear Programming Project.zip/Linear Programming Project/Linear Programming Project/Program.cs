﻿using Linear_Programming_Project.Algorithms;
using Linear_Programming_Project.BusinessLogic;
using Linear_Programming_Project.File_Handling;
using MathNet.Numerics.LinearAlgebra;

namespace Linear_Programming_Project
{
	/// <summary>
	///  Enum classes for the 3 different navigatations
	///  AlgorithmType  Enum: Enumeration for different algorithms  the program offers for the users to use.
	///  MenuOption Enum: Enumeration for main menu options.
	///  SensitivityAnalysisTasks Enum: Enumeration for sensitivity analysis tasks the program offers.
	/// </summary>
	public enum AlgorithmType
	{
		PrimalSimplex = 1,
		DualSimplex,
		BranchAndBoundSimplex,
		CuttingPlane,
		BranchAndBoundKnapsack,
		Duality
	}
	public enum MenuOption
	{
		SolveModel = 1,
		SensitivityAnalysis,
		ExportResults,
		Exit
	}
	public enum SensitivityAnalysisTasks
	{
		DisplayMatrices = 1,
		NonBasicVariableOBFunChange,
		BasicVariableOBFunChange,
		RHSVariableChange,
		NonBasicColumnVariableChange,
		BasicColumnVariableChange,
		ShadowPrices,
		AddConstraint,
		AddActivity,
		Back
	}
	public class AlgorithmResults
		{
			public double[,] InitialTable { get; set; }
			public List<double[,]> TableauHistory { get; set; }
			public double[,] FinalTable { get; set; }
			public string SolutionStatus { get; set; }
		}


	/// <summary>
	/// This code provides a console-based interface for solving linear programming models using different algorithms. 
	/// The Program class includes enums for selecting algorithms and menu options, and a main loop for user interaction. 
	/// Users can choose to solve the model, perform sensitivity analysis, export results, or exit. 
	/// The SolveModel method selects the appropriate algorithm and calls DisplayResults to show the results. 
	/// The DisplayResults method displays different results based on the type of algorithm used. 
	/// The DisplayTable method formats tables for console output, and ExportResults is a method for exporting results to a file.
	/// </summary>
	class Program
	{ 
		// Variable to store the last result
		static AlgorithmResults lastResults = null;

		static void Main(string[] args)
		{
			var inputOutput = new Input_Output(); // Handles file input and output
			LinearProgramingModel model = null; // The linear programming model to be used
			bool running = true;

			// Main loop for user interaction
			while (running)
			{
				Console.Clear();
				Console.WriteLine("Please select which operation to perform:\n");
				Console.WriteLine("\t1. Solve Model");
				Console.WriteLine("\t2. Sensitivity Analysis");
				Console.WriteLine("\t3. Export Results");
				Console.WriteLine("\t4. Exit");
				Console.Write("\nSelect an option (1-4): ");
				
				if (Enum.TryParse(Console.ReadLine(), out MenuOption option))
				{
					switch (option)
					{
						// Handle model solving
						case MenuOption.SolveModel:
						{
							model = inputOutput.ImportLPFile("Example Primal Simplex.txt"); // Load the LP model from a file to solve
							if (model != null)
							{
								Console.WriteLine("\nPlease select an algorithm to perform on the LP model:\n");
								foreach (AlgorithmType alg in Enum.GetValues(typeof(AlgorithmType)))
								{
									Console.WriteLine($"\t{(int)alg}. {alg}"); // Display available algorithms
								}
								Console.Write("\nAlgorithm (1-5): ");

								if (Enum.TryParse(Console.ReadLine(), out AlgorithmType algorithm))
								{
									SolveModel(model, algorithm); // Solve the model with the selected algorithm
								}
								else
								{
									Console.WriteLine("Invalid algorithm selection.");
								}
							}
							else
							{
								Console.WriteLine("Failed to load the model.");
							}
						}
						break;

						//Handle sensitivity analysis
						case MenuOption.SensitivityAnalysis:
						{
							lastResults = ConvertToCanonical(lastResults);

							SensitivityAnalysis sensitivity = new SensitivityAnalysis();
							if (model != null)
							{
								bool continueLoop = true;

								while (continueLoop)
								{
									Console.Clear();
									Console.WriteLine("Sensitivity Analysis Menu:");
									Console.WriteLine("\t1. Display Matrices");
									Console.WriteLine("\t2. Non-Basic Variable Objective Function Value Change and Range");
									Console.WriteLine("\t3. Basic Variable Objective Function Value Change and Range");
									Console.WriteLine("\t4. RHS Variable Change");
									Console.WriteLine("\t5. Non-Basic Column Value Change");
									Console.WriteLine("\t6. Basic Column Value Change");
									Console.WriteLine("\t7. Shadow Prices");
									Console.WriteLine("\t8. Add Constraint");
									Console.WriteLine("\t9. Add Activity");
									Console.WriteLine("\t10. Back");
									Console.Write("\nSelect an option (1-10): ");

									if (Enum.TryParse(Console.ReadLine(), out SensitivityAnalysisTasks task))
									{
										switch (task)
										{
											case SensitivityAnalysisTasks.DisplayMatrices:
											{

												sensitivity.SensitivityMatrices(lastResults);
											}
											break;

											case SensitivityAnalysisTasks.NonBasicVariableOBFunChange:
											{
												sensitivity.NonBasicVariableOBFunChange(lastResults); // Display range of non-basic variables method
											}
											break;
											case SensitivityAnalysisTasks.BasicVariableOBFunChange:
											{
												sensitivity.BasicVariableOBFunChange(lastResults); // Display range of basic variables method
											}
											break;

											case SensitivityAnalysisTasks.RHSVariableChange:
											{
												sensitivity.RHSVariableChange(lastResults); // Display changes in basic variables method
											}
											break;
											case SensitivityAnalysisTasks.NonBasicColumnVariableChange:
											{
												sensitivity.NonBasicColumnVariableChange(lastResults); // Display changes in basic variables method
											}
											break;
											case SensitivityAnalysisTasks.BasicColumnVariableChange:
											{
												sensitivity.BasicColumnVariableChange(lastResults); // Display changes in basic variables method
											}
											break;
											case SensitivityAnalysisTasks.ShadowPrices:
											{
												sensitivity.ShadowPrices(lastResults); // Display changes in basic variables method
											}
											break;
											case SensitivityAnalysisTasks.AddConstraint:
											{
												sensitivity.AddConstraint(lastResults); // Add a new constraint
											}
											break;
											case SensitivityAnalysisTasks.AddActivity:
											{
												sensitivity.AddActivity(lastResults); // Add a new activity method
											}
											break;
											case SensitivityAnalysisTasks.Back:
											{
												continueLoop = false; // Exit sensitivity analysis menu and return to the Main menu option
											}
											break;
										}
									}
									else
									{
										Console.WriteLine("Error: Invalid option selected.");
									}
									Console.ReadKey();
								}
							}
							else
							{
								Console.WriteLine("Error: No model solution was calculated.");
							}
						}
						break;

						// Handle result export
						case MenuOption.ExportResults:
						{
							if (model != null && lastResults != null)
							{
								ExportResults(model); // Call the Export results to file method
							}
							else
							{
								Console.WriteLine("Error: No model loaded or no results to export.");
							}
						}
						break;

						// Exit the application
						case MenuOption.Exit:
						{
							running = false;
							Console.WriteLine("\n ======================================================================\n" +
								"Linear Programming  Algorithm Application\n" +
								"Group V7\n" +
								"Coders:\n" +
								"\tNicholas Coetzee (576940)\n" +
								"\tRuan Leenders (578427)\n" +
								"\tZoë Treutens (577989)\n" +
								"======================================================================\n" +
								"\nNote to Lecturer:\n" +
								"Please be advised that the student Gideon Rossouw (576737) did not participate in any of the coding for this project and even ignored the group members private and in the created whatsapp group text messages." +
								"\nAs such we have collectively decided to remove his name from our group.");
						}
						break;

						default:
						{
							Console.WriteLine("Error: Invalid option selected.");
						}
						break;
					}
				}
				else
				{
					Console.WriteLine("Error: Invalid option selected.");
				}
				Console.ReadLine();
			}
		}

		// Solve the LP model using the selected algorithm
		public static void SolveModel(LinearProgramingModel model, AlgorithmType algorithm)
		{
			AlgorithmResults results = new AlgorithmResults();

			switch (algorithm)
			{
				case AlgorithmType.PrimalSimplex:
				{
					var primalSimplex = new PrimalSimplex();
					var primalSimplexResult = primalSimplex.Solve(model);
					DisplayResults(primalSimplexResult); // Display results of Primal Simplex
					results.InitialTable = primalSimplexResult.InitialTable;
					results.TableauHistory = primalSimplexResult.TableauHistory;
					results.FinalTable = primalSimplexResult.FinalTable;
					results.SolutionStatus = primalSimplexResult.SolutionStatus.ToString();
				}
				break;

				case AlgorithmType.BranchAndBoundSimplex:
				{
					var branchAndBoundSimplex = new BranchAndBound();
					var branchAndBoundSimplexResult = branchAndBoundSimplex.Solve(model);
					DisplayResults(branchAndBoundSimplexResult); // Display results of Branch and Bound Simplex
					results.InitialTable = branchAndBoundSimplexResult.InitialTable;
					results.TableauHistory = branchAndBoundSimplexResult.TableauHistory;
					results.FinalTable = branchAndBoundSimplexResult.FinalTable;
					results.SolutionStatus = branchAndBoundSimplexResult.SolutionStatus.ToString();
				}
				break;

				case AlgorithmType.CuttingPlane:
				{
					var cuttingPlane = new CuttingPlane();
					var cuttingPlaneResult = cuttingPlane.Solve(model);
					DisplayResults(cuttingPlaneResult); // Display results of Cutting Plane
					results.InitialTable = cuttingPlaneResult.InitialTable;
					results.TableauHistory = cuttingPlaneResult.TableauHistory;
					results.FinalTable = cuttingPlaneResult.FinalTable;
					results.SolutionStatus = cuttingPlaneResult.SolutionStatus.ToString();
				}
				break;

				case AlgorithmType.BranchAndBoundKnapsack:
				{
					var solver = new KnapsackBranchAndBoundSolver(model);
					solver.Execute();
				}	break;

				case AlgorithmType.DualSimplex:
				{
					var dualSimplex = new DualSimplex();
					var DualSimplexResult = dualSimplex.Solve(model);
					DisplayResults(DualSimplexResult);
					results.InitialTable = DualSimplexResult.InitialTable;
					results.FinalTable = DualSimplexResult.FinalTable;
					results.SolutionStatus = DualSimplexResult.SolutionStatus.ToString();
				}
				break;
				case AlgorithmType.Duality:
				{
					var duality = new Duality();
					var DualityResult = duality.Solve(model);
					DisplayResults(DualityResult);
					results.FinalTable = DualityResult.FinalTable;
					results.SolutionStatus = DualityResult.SolutionStatus.ToString();
				}
				break;

				default:
				{
					Console.WriteLine("Unknown algorithm.");
				}
				break;
			}
			lastResults = results;
		}

		// Display the results of the selected algorithm
		static void DisplayResults(object result)
		{
			if (result is PrimalSimplexResult primalSimplexResult)
			{
				Console.WriteLine("\n");
				DisplayTable(primalSimplexResult.InitialTable, "Canonical / Initial Table");

				Console.WriteLine("\nTable Iterations:");
				int iterationNumber = 1;
				foreach (var tableau in primalSimplexResult.TableauHistory)
				{
					DisplayTable(tableau, $"\nTable: {iterationNumber++}");
				}

				Console.WriteLine("\n");
				DisplayTable(primalSimplexResult.FinalTable, "Optimal Table");
				Console.WriteLine($"\nSolution Status: {primalSimplexResult.SolutionStatus}");
			}
			else if (result is BranchAndBoundResult branchAndBoundSimplexResult)
			{
				Console.WriteLine("\n");
				DisplayTable(branchAndBoundSimplexResult.InitialTable, "Canonical / Initial Table");

				Console.WriteLine("\n");
				DisplayTable(branchAndBoundSimplexResult.FinalTable, "Optimal Table");
				Console.WriteLine($"\nSolution Status: {branchAndBoundSimplexResult.SolutionStatus}");
			}
			else if (result is CuttingPlaneResult cuttingPlaneResult)
			{
				Console.WriteLine("\n");
				DisplayTable(cuttingPlaneResult.InitialTable, "Canonical / Initial Table");

				Console.WriteLine("\n");
				Console.WriteLine($"Cutting variable in row {cuttingPlaneResult.FractionalVariableIndex + 1} due to fractional RHS.");

				Console.WriteLine("\n");
				DisplayTable(cuttingPlaneResult.FinalTable, "Optimal Table");
				Console.WriteLine($"\nSolution Status: {cuttingPlaneResult.SolutionStatus}");
			}
			else if (result is DualSimplexResult dualSimplexResult)
			{
				Console.WriteLine("\n");
				DisplayTable(dualSimplexResult.InitialTable, "Canonical / Initial Table");

				Console.WriteLine("\n");
				DisplayTable(dualSimplexResult.FinalTable, "Optimal Table");
				Console.WriteLine($"\nSolution Status: {dualSimplexResult.SolutionStatus}");
			}
			else if (result is DualityResult dualityResult)
			{
				Console.WriteLine("\n");
				DisplayTable(dualityResult.PrimalForm, "Primal Table");

				Console.WriteLine("\n");
				DisplayTable(dualityResult.DualForm, "Dual Table");
				Console.WriteLine($"\nSolution Status: {dualityResult.SolutionStatus}");
			}
			else
			{
				Console.WriteLine("Unknown result type.");
			}
		}

		// Display a table in the console
		static void DisplayTable(double[,] table, string tableName, List<string> slackVariables = null, List<string> excessVariables = null)
		{
			if (table == null)
			{
				Console.WriteLine($"Error: {tableName} is null.");
				return;
			}

			int rows = table.GetLength(0);
			int cols = table.GetLength(1);

			// Determine maximum width for each column
			int[] columnWidths = new int[cols];
			for (int j = 0; j < cols; j++)
			{
				columnWidths[j] = 0;
				for (int i = 0; i < rows; i++)
				{
					// Determine if the value is an integer or a decimal
					string formattedValue = table[i, j] % 1 == 0 ? table[i, j].ToString("0") : table[i, j].ToString("F3");
					int length = formattedValue.Length;
					if (length > columnWidths[j])
					{
						columnWidths[j] = length;
					}
				}
				// Add extra space for formatting
				columnWidths[j] += 2; // Adjust as needed for padding
			}

			// Add headers to column widths for the final row
			string[] headers = new string[cols];
			for (int j = 0; j < cols - 1; j++)
			{
				headers[j] = $"X{j + 1}";
			}
			headers[cols - 1] = "RHS"; // Adjust header as needed

			// Add slack and excess variable headers if present
			if (slackVariables != null && slackVariables.Count > 0)
			{
				headers = headers.Concat(slackVariables).ToArray();
			}
			if (excessVariables != null && excessVariables.Count > 0)
			{
				headers = headers.Concat(excessVariables).ToArray();
			}
			// Used Padding to ensure the table columns are even and aligned
			string headerLine = "| " + string.Join(" | ", headers.Select((header, index) => header.PadRight(columnWidths[index])));
			string separatorLine = "|-" + string.Join("-|-", columnWidths.Select(width => new string('-', width))) + "-|-";

			Console.WriteLine($"{tableName}:");
			Console.WriteLine(separatorLine);
			Console.WriteLine(headerLine);
			Console.WriteLine(separatorLine);

			// Display table rows
			for (int i = 0; i < rows; i++)
			{
				Console.Write("| ");
				for (int j = 0; j < cols; j++)
				{
					// Format value based on whether it's an integer or decimal
					string formattedValue = table[i, j] % 1 == 0 ? table[i, j].ToString("0") : table[i, j].ToString("F3");
					Console.Write(formattedValue.PadLeft(columnWidths[j]) + " | ");
				}
				Console.WriteLine();
				Console.WriteLine(separatorLine);
			}
		}

		public static AlgorithmResults ConvertToCanonical(AlgorithmResults results)
		{
			// Retrieve the objective function row from the final table
			double[,] initialTable = lastResults.InitialTable;
			int numVariables = initialTable.GetLength(1) - 1; // excluding RHS

			// Ensure the objective function row is multiplied by -1 (converting to canonical form)
			for (int i = 0; i < numVariables; i++)
			{
				initialTable[0, i] *= -1;
			}

			// Update lastResults with the new objective function values
			lastResults.InitialTable = initialTable;
			return lastResults;
		}

		// Exporting the relevant information for the different algorithms to an output.txt file
		static void ExportResults(LinearProgramingModel model)
		{
			var inputOutput = new Input_Output();

			if (lastResults != null)
			{
				// Use lastResults to export data
				inputOutput.ExportResultsToFile(
					lastResults.InitialTable,
					lastResults.TableauHistory,
					lastResults.FinalTable,
					lastResults.SolutionStatus
				);
				Console.WriteLine("Results successfully exported to file.");
			}
			else
			{
				Console.WriteLine("Error: No results to export.");
			}
		}
	}
}